import svgPaths from "./svg-z9oi9p46gx";

function Heading() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="-translate-x-1/2 absolute font-['Arimo:Bold',sans-serif] font-bold leading-[48px] left-[175.52px] text-[#3d1f00] text-[32px] text-center top-[1.4px] whitespace-nowrap">Premium</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-[176.49px] text-[#83451e] text-[16px] text-center top-[0.2px] w-[248px]">Получите полный доступ ко всем возможностям NIKA</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[104px] items-start left-[48px] top-[48px] w-[352px]" data-name="Container">
      <Heading />
      <Paragraph />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[48px] left-[86.67px] top-0 w-[80.088px]" data-name="Text">
      <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[48px] left-0 text-[#3d1f00] text-[48px] top-[-0.2px] whitespace-nowrap">299</p>
    </div>
  );
}

function Text1() {
  return (
    <div className="absolute h-[36px] left-[174.76px] top-[8px] w-[45.763px]" data-name="Text">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-0 text-[#83451e] text-[24px] top-[0.8px] whitespace-nowrap">руб.</p>
    </div>
  );
}

function Text2() {
  return (
    <div className="absolute h-[24px] left-[228.52px] top-[16px] w-[36.8px]" data-name="Text">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-0 text-[#83451e] text-[16px] top-[0.2px] whitespace-nowrap">/ мес</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[48px] left-[48px] top-[184px] w-[352px]" data-name="Container">
      <Text />
      <Text1 />
      <Text2 />
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[12px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-13.64%_-9.38%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
            <path d={svgPaths.p1c198100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute bg-[#f5a623] content-stretch flex flex-col items-start left-0 pt-[4px] px-[4px] rounded-[26843500px] size-[20px] top-[4px]" data-name="Container">
      <Icon />
    </div>
  );
}

function Text3() {
  return (
    <div className="absolute h-[40px] left-[32px] top-0 w-[320px]" data-name="Text">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#3d1f00] text-[16px] top-[-0.2px] w-[306px]">Полный доступ к персонализированному сопровождению</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="Container">
      <Container5 />
      <Text3 />
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[12px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-13.64%_-9.38%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
            <path d={svgPaths.p1c198100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute bg-[#f5a623] content-stretch flex flex-col items-start left-0 pt-[4px] px-[4px] rounded-[26843500px] size-[20px] top-[4px]" data-name="Container">
      <Icon1 />
    </div>
  );
}

function Text4() {
  return (
    <div className="absolute h-[20px] left-[32px] top-0 w-[221.262px]" data-name="Text">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[-0.6px] text-[#3d1f00] text-[16px] top-[3.9px] whitespace-nowrap">Расширенный анализ данных</p>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <Container7 />
      <Text4 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[12px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-13.64%_-9.38%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
            <path d={svgPaths.p1c198100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute bg-[#f5a623] content-stretch flex flex-col items-start left-0 pt-[4px] px-[4px] rounded-[26843500px] size-[20px] top-[4px]" data-name="Container">
      <Icon2 />
    </div>
  );
}

function Text5() {
  return (
    <div className="absolute h-[20px] left-[32.4px] top-[3.9px] w-[306.113px]" data-name="Text">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#3d1f00] text-[16px] top-[-0.2px] whitespace-nowrap">Постоянная адаптация личной стратегии</p>
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <Container9 />
      <Text5 />
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[120px] items-start left-[48px] top-[272px] w-[352px]" data-name="Container">
      <Container4 />
      <Container6 />
      <Container8 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#f5a623] h-[59px] left-[48px] rounded-[15px] shadow-[0px_4px_6px_0px_rgba(0,0,0,0.1),0px_2px_4px_0px_rgba(0,0,0,0.1)] top-[432px] w-[352px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[27px] left-[175.71px] text-[18px] text-center text-white top-[16.2px] whitespace-nowrap">Оформить подписку</p>
    </div>
  );
}

function Container10() {
  return <div className="absolute bg-[#f5a623] h-[8px] left-0 top-0 w-[448px]" data-name="Container" />;
}

function Container() {
  return (
    <div className="absolute bg-white h-[539px] left-[355.6px] overflow-clip rounded-[30px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] top-[64.1px] w-[448px]" data-name="Container">
      <Container1 />
      <Container2 />
      <Container3 />
      <Button />
      <Container10 />
    </div>
  );
}

function T() {
  return (
    <div className="absolute bg-[#fffee7] h-[667.2px] left-0 top-0 w-[1159.2px]" data-name="T0">
      <Container />
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M12 19L5 12L12 5" id="Vector" stroke="var(--stroke-0, #83451E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M19 12H5" id="Vector_2" stroke="var(--stroke-0, #83451E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[45.85px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-[23px] text-[#83451e] text-[16px] text-center top-[0.2px] whitespace-nowrap">Назад</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[24px] items-center left-[32px] top-[32px] w-[77.85px]" data-name="Button">
      <Icon3 />
      <Text6 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white relative size-full" data-name="страница оформить подписку">
      <T />
      <Button1 />
    </div>
  );
}