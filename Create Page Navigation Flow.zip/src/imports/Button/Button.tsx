function Icon() {
  return (
    <div className="absolute left-[15px] size-[24px] top-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_167)" id="Icon">
          <path d="M9 12L3 6L9 0" id="Vector" stroke="var(--stroke-0, #364153)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_167">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

export default function Button() {
  return (
    <div className="bg-white border border-[#e5e7eb] border-solid relative rounded-[16px] size-full" data-name="Button">
      <Icon />
    </div>
  );
}