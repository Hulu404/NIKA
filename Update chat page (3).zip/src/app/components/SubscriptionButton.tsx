interface SubscriptionButtonProps {
  hasActiveSubscription: boolean;
  onClick?: () => void;
}

export function SubscriptionButton({ hasActiveSubscription, onClick }: SubscriptionButtonProps) {
  if (hasActiveSubscription) {
    return (
      <div className="flex items-center gap-[8px] bg-gradient-to-r from-[#00bc7d]/10 to-[#00bc7d]/5 border border-[#00bc7d]/20 rounded-[12px] px-[16px] py-[8px]">
        <div className="size-[8px] bg-[#00bc7d] rounded-full animate-pulse" />
        <span className="font-['Arimo:Bold',sans-serif] text-[13px] text-[#00bc7d]">
          Активная подписка
        </span>
      </div>
    );
  }

  return (
    <button
      onClick={onClick}
      className="relative group overflow-hidden bg-gradient-to-r from-[#f6b044] to-[#f39c12] rounded-[12px] px-[20px] py-[10px] shadow-[0px_4px_12px_0px_rgba(246,176,68,0.3)] transition-all duration-300 hover:shadow-[0px_6px_20px_0px_rgba(246,176,68,0.5)] hover:scale-[1.02] active:scale-[0.98]"
    >
      {/* Shine effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />

      <div className="relative flex items-center gap-[8px]">
        <svg className="size-[16px]" fill="none" viewBox="0 0 16 16">
          <path d="M8 1L10.472 5.96L16 6.765L12 10.68L12.944 16L8 13.36L3.056 16L4 10.68L0 6.765L5.528 5.96L8 1Z" fill="white" />
        </svg>
        <span className="font-['Arimo:Bold',sans-serif] text-[14px] text-white whitespace-nowrap">
          Получить подписку
        </span>
      </div>
    </button>
  );
}
