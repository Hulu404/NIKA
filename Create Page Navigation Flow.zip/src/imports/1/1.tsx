import svgPaths from "./svg-otbpxl037u";

function Text() {
  return <div className="h-[20px] shrink-0 w-[19.766px]" data-name="Text" />;
}

function Container3() {
  return <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] shrink-0 w-[32px]" data-name="Container" />;
}

function Container4() {
  return <div className="bg-[#e5e7eb] h-[6px] rounded-[33554400px] shrink-0 w-[32px]" data-name="Container" />;
}

function Container7() {
  return <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[290px] rounded-[26843500px] size-[384px] top-[-159px]" data-name="Container" />;
}

function Container8() {
  return <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" data-name="Container" />;
}

function Container6() {
  return (
    <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[674px] left-[-786px] opacity-50 rounded-[26843500px] top-[-39px] w-[1333px]" data-name="Container">
      <Container7 />
      <Container8 />
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[#e5e7eb] flex-[1_0_0] h-[6px] min-w-px relative rounded-[33554400px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container6 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[6px] left-[calc(50%+0.5px)] top-1/2 w-[112px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-start relative size-full">
        <Container3 />
        <Container4 />
        <Container5 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-between left-[24px] top-[32px] w-[624px]" data-name="Container">
      <Text />
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#6a7282] text-[14px] whitespace-nowrap">1/3</p>
      <Container2 />
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Icon">
          <path d={svgPaths.p19a01780} id="Vector" stroke="var(--stroke-0, #8600C4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d={svgPaths.p15663e00} id="Vector_2" stroke="var(--stroke-0, #8600C4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d={svgPaths.p3911f600} id="Vector_3" stroke="var(--stroke-0, #8600C4)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="bg-[#f1e0ff] flex-[1_0_0] min-h-px relative rounded-[16px] w-[80px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[20px] relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[28px] relative shrink-0 w-[131.641px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Доказать себе</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[124px] relative shrink-0 w-[131.641px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-center relative size-full">
        <Container12 />
        <Text1 />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Icon">
          <path d={svgPaths.p8c5680} id="Vector" stroke="var(--stroke-0, #FF7700)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d="M33.3333 5V11.6667" id="Vector_2" stroke="var(--stroke-0, #FF7700)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d="M36.6667 8.33333H30" id="Vector_3" stroke="var(--stroke-0, #FF7700)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d="M6.66667 28.3333V31.6667" id="Vector_4" stroke="var(--stroke-0, #FF7700)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d="M8.33333 30H5" id="Vector_5" stroke="var(--stroke-0, #FF7700)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container14() {
  return (
    <div className="bg-[#faebd0] flex-[1_0_0] min-h-px relative rounded-[16px] w-[80px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[20px] relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[28px] relative shrink-0 w-[113.297px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Ловить кайф</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[124px] relative shrink-0 w-[113.297px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-center relative size-full">
        <Container14 />
        <Text2 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute content-stretch flex h-[124px] items-center justify-between left-[49px] top-[286px] w-[526px]" data-name="Container">
      <Container11 />
      <Container13 />
    </div>
  );
}

function RangeSlider() {
  return <div className="bg-gradient-to-r from-[#a135ff] h-[12px] rounded-[33554400px] shrink-0 to-[#ffb261] w-full" data-name="Range Slider" />;
}

function Container16() {
  return (
    <div className="content-stretch flex flex-col h-[40px] items-start pt-[14px] relative shrink-0 w-full" data-name="Container">
      <RangeSlider />
      <div className="absolute left-[242.5px] size-[42px] top-[-1px]">
        <div className="absolute inset-[-4.76%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 46 46">
            <circle cx="23" cy="23" fill="var(--fill-0, white)" id="Ellipse 1" r="22" stroke="var(--stroke-0, #A63BF6)" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-[263.02px] not-italic text-[#101828] text-[24px] text-center top-[-1px] whitespace-nowrap">Баланс</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[263px] not-italic text-[#6a7282] text-[18px] text-center top-0 whitespace-nowrap">0.0</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[68px] items-start relative shrink-0 w-full" data-name="Container">
      <Paragraph />
      <Paragraph1 />
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[132px] items-start left-[49px] top-[474px] w-[526px]" data-name="Container">
      <Container16 />
      <Container17 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#f3f4f6] h-[68px] left-[49px] rounded-[16px] top-[638px] w-[526px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-[263.67px] not-italic text-[#99a1af] text-[18px] text-center top-[20px] whitespace-nowrap">Далее</p>
    </div>
  );
}

function MotivationSlider1() {
  return (
    <div className="absolute h-[282px] left-0 not-italic text-center top-[52px] w-[624px]" data-name="MotivationSlider">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[120px] leading-[60px] left-0 right-0 text-[#101828] text-[48px] top-0">Что для тебя важнее в тренировках?</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[64px] leading-[32px] left-0 right-0 text-[#4a5565] text-[24px] top-[144px]">Выбери, что чаще подталкивает тебя надеть кроссовки</p>
    </div>
  );
}

function MotivationSlider() {
  return (
    <div className="absolute bg-white border border-[#f3f4f6] border-solid h-[738px] left-[0.5px] rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] top-[18px] w-[624px]" data-name="MotivationSlider">
      <Container10 />
      <Container15 />
      <Button />
      <MotivationSlider1 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute h-[774px] left-[24px] top-[100px] w-[624px]" data-name="Container">
      <MotivationSlider />
    </div>
  );
}

function Container() {
  return (
    <div className="flex-[906_0_0] min-h-px relative w-[672px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container1 />
        <Container9 />
      </div>
    </div>
  );
}

function OnboardingWizard() {
  return (
    <div className="bg-[#faf7ec] content-stretch flex flex-col h-[906px] items-start pl-[425.5px] relative shrink-0 w-[1523px]" data-name="OnboardingWizard">
      <Container />
    </div>
  );
}

export default function Component() {
  return (
    <div className="content-stretch flex flex-col items-start relative size-full" data-name="1">
      <OnboardingWizard />
    </div>
  );
}