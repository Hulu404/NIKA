export default {
p1c198100: "M8.75 0.75L3.25 6.25L0.75 3.75",
}
