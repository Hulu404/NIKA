import { useState, useCallback, useRef, useEffect } from 'react';

// Import only the step components we use
import Step0 from '../imports/0/0';

type K6Answer = 0 | 1 | 2 | 3 | 4 | null;
type MotivationChoice = 'prove' | 'enjoy' | null;
type LocusChoice = 'internal' | 'external' | null;

interface WizardState {
  slider: number; // -1.0 to +1.0
  k6: K6Answer[];
  locus: LocusChoice;
}

export default function App() {
  const [currentStep, setCurrentStep] = useState(0);
  const [wizardState, setWizardState] = useState<WizardState>({
    slider: 0,
    k6: [null, null, null, null, null, null],
    locus: null,
  });

  // Navigation handlers
  const goToNextStep = useCallback(() => {
    setCurrentStep(prev => Math.min(prev + 1, 8));
  }, []);

  const goToPreviousStep = useCallback(() => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  }, []);

  // Answer handlers
  const setSliderValue = useCallback((value: number) => {
    setWizardState(prev => ({ ...prev, slider: value }));
  }, []);

  const setK6Answer = useCallback((questionIndex: number, answer: K6Answer) => {
    setWizardState(prev => {
      const newK6 = [...prev.k6];
      newK6[questionIndex] = answer;
      return { ...prev, k6: newK6 };
    });
  }, []);

  const setLocusAnswer = useCallback((choice: LocusChoice) => {
    setWizardState(prev => ({ ...prev, locus: choice }));
  }, []);

  const handleComplete = useCallback(() => {
    console.log('Assessment Complete!', {
      slider: wizardState.slider,
      k6: wizardState.k6,
      locus: wizardState.locus,
    });
    alert(
      `Психологический онбординг завершен!\n\n` +
      `Результаты:\n` +
      `- Мотивация: ${wizardState.slider.toFixed(2)}\n` +
      `- K6: [${wizardState.k6.join(', ')}]\n` +
      `- Локус контроля: ${wizardState.locus}\n\n` +
      `Данные выведены в консоль.`
    );
  }, [wizardState]);

  const handleClose = useCallback(() => {
    const confirmed = confirm('Вы уверены, что хотите закрыть онбординг? Прогресс не будет сохранён.');
    if (confirmed) {
      console.log('Onboarding closed by user');
      // Here you would typically redirect or close the modal
      alert('Онбординг закрыт. В реальном приложении произойдёт редирект.');
    }
  }, []);

  // Render current step
  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return <Step0Wrapper onStart={goToNextStep} onClose={handleClose} />;
      case 1:
        return (
          <Step1Wrapper
            sliderValue={wizardState.slider}
            onSliderChange={setSliderValue}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 2:
        return (
          <K6Wrapper
            questionIndex={0}
            selectedAnswer={wizardState.k6[0]}
            onAnswerSelect={(answer) => setK6Answer(0, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 3:
        return (
          <K6Wrapper
            questionIndex={1}
            selectedAnswer={wizardState.k6[1]}
            onAnswerSelect={(answer) => setK6Answer(1, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 4:
        return (
          <K6Wrapper
            questionIndex={2}
            selectedAnswer={wizardState.k6[2]}
            onAnswerSelect={(answer) => setK6Answer(2, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 5:
        return (
          <K6Wrapper
            questionIndex={3}
            selectedAnswer={wizardState.k6[3]}
            onAnswerSelect={(answer) => setK6Answer(3, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 6:
        return (
          <K6Wrapper
            questionIndex={4}
            selectedAnswer={wizardState.k6[4]}
            onAnswerSelect={(answer) => setK6Answer(4, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 7:
        return (
          <K6Wrapper
            questionIndex={5}
            selectedAnswer={wizardState.k6[5]}
            onAnswerSelect={(answer) => setK6Answer(5, answer)}
            onBack={goToPreviousStep}
            onNext={goToNextStep}
          />
        );
      case 8:
        return (
          <Step3Wrapper
            selectedChoice={wizardState.locus}
            onChoiceSelect={setLocusAnswer}
            onBack={goToPreviousStep}
            onComplete={handleComplete}
          />
        );
      default:
        return <Step0Wrapper onStart={goToNextStep} onClose={handleClose} />;
    }
  };

  return <div className="size-full">{renderStep()}</div>;
}

// Step 0 Wrapper - Introduction
function Step0Wrapper({ onStart, onClose }: { onStart: () => void; onClose: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.textContent?.includes('Начать')) {
        onStart();
      }
    };

    container.addEventListener('click', handleClick);
    return () => container.removeEventListener('click', handleClick);
  }, [onStart]);

  return (
    <div ref={containerRef} className="size-full relative">
      <style>{`
        [data-name="0"] [data-name="Button"] {
          background: #4f39f6 !important;
          cursor: pointer;
          transition: background 0.2s;
        }
        [data-name="0"] [data-name="Button"]:hover {
          background: #4530d6 !important;
        }
        [data-name="0"] [data-name="Button"] p {
          color: white !important;
        }
      `}</style>
      {/* Close button - top right */}
      <button
        onClick={onClose}
        className="absolute top-[24px] right-[24px] size-[32px] rounded-full bg-white border border-[#e5e7eb] flex items-center justify-center hover:bg-[#f3f4f6] transition-colors z-10"
      >
        <svg className="size-[16px]" fill="none" viewBox="0 0 16 16">
          <path d="M12 4L4 12M4 4L12 12" stroke="#6a7282" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </button>
      <Step0 />
    </div>
  );
}

// Step 1 Wrapper - Motivation Slider (Custom Implementation)
function Step1Wrapper({
  sliderValue,
  onSliderChange,
  onBack,
  onNext,
}: {
  sliderValue: number;
  onSliderChange: (value: number) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const sliderRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const hasInteracted = useRef(sliderValue !== 0);

  useEffect(() => {
    if (sliderValue !== 0) {
      hasInteracted.current = true;
    }
  }, [sliderValue]);

  const updateSliderValue = (clientX: number) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    // Convert 0-100 to -1.0 to +1.0
    const value = (percentage / 50) - 1;
    onSliderChange(Math.max(-1, Math.min(1, value)));
  };

  const handleSliderMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    updateSliderValue(e.clientX);
  };

  const handleSliderClick = (e: React.MouseEvent) => {
    updateSliderValue(e.clientX);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging.current) {
        updateSliderValue(e.clientX);
      }
    };

    const handleMouseUp = () => {
      isDragging.current = false;
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Calculate slider position (0-100% from -1.0 to +1.0)
  const sliderPercentage = ((sliderValue + 1) / 2) * 100;

  // Get label based on value ranges from ТЗ
  const getSliderLabel = () => {
    if (sliderValue <= -0.7) return 'Только результат';
    if (sliderValue <= -0.3) return 'Скорее результат';
    if (sliderValue <= 0.2) return 'Баланс';
    if (sliderValue <= 0.6) return 'Скорее удовольствие';
    return 'Только кайф';
  };

  return (
    <div className="size-full bg-[#faf7ec] flex justify-center overflow-y-auto">
      <div className="w-[672px] flex flex-col gap-[48px] px-[24px] pt-[32px] pb-[32px]">
        {/* Background decoration */}
        <div className="relative h-0">
          <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[674px] left-[-786px] opacity-50 rounded-[26843500px] top-[-39px] w-[1333px] z-[-1]">
            <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[290px] rounded-[26843500px] size-[384px] top-[-159px]" />
            <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" />
          </div>
        </div>

        {/* Top section with back button and progress */}
        <div className="relative h-[44px] w-[624px]">
          {/* Back button */}
          <button
            onClick={onBack}
            className="absolute left-0 top-0 bg-white border border-[#e5e7eb] rounded-[16px] size-[44px] flex items-center justify-center hover:bg-[#f3f4f6] transition-colors"
          >
            <svg className="size-[24px]" fill="none" viewBox="0 0 24 24">
              <path d="M15 18L9 12L15 6" stroke="#364153" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </button>

          {/* Progress indicator */}
          <div className="absolute left-0 top-[12px] h-[20px] w-[624px]">
            {/* Progress dots - centered */}
            <div className="absolute left-[256.5px] top-[9px] h-[6px] w-[112px] flex gap-[8px]">
              <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] w-[32px]" />
              <div className="bg-[#e5e7eb] h-[6px] rounded-[33554400px] w-[32px]" />
              <div className="bg-[#e5e7eb] h-[6px] rounded-[33554400px] w-[32px]" />
            </div>
            {/* Section text - right aligned */}
            <div className="absolute left-[601.41px] top-0 h-[20px]">
              <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] text-[#6a7282] text-[14px] whitespace-nowrap">1/3</p>
            </div>
          </div>
        </div>

        {/* Main content card */}
        <div className="w-[624px] bg-white border border-[#f3f4f6] rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] p-[49px] pb-[32px]">

          {/* Title */}
          <div className="text-center mb-[52px]">
            <h1 className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[48px] leading-[60px] text-[#101828]">
              Что для тебя важнее в тренировках?
            </h1>
            <p className="font-['Inter:Regular',sans-serif] text-[24px] leading-[32px] text-[#4a5565] mt-[24px]">
              Выбери, что чаще подталкивает тебя надеть кроссовки
            </p>
          </div>

          {/* Icon choices */}
          <div className="flex justify-between mb-[68px]">
            <div className="flex flex-col items-center gap-[16px]">
              <div className="bg-[#f1e0ff] w-[80px] h-[80px] rounded-[16px] flex items-center justify-center">
                <svg className="size-[40px]" fill="none" viewBox="0 0 40 40">
                  <path d="M13.3333 33.3333C17.0152 33.3333 20 30.3486 20 26.6667C20 22.9848 17.0152 20 13.3333 20C9.65142 20 6.66666 22.9848 6.66666 26.6667C6.66666 30.3486 9.65142 33.3333 13.3333 33.3333Z" stroke="#8600C4" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M26.6667 20C30.3486 20 33.3333 17.0152 33.3333 13.3333C33.3333 9.65142 30.3486 6.66666 26.6667 6.66666C22.9848 6.66666 20 9.65142 20 13.3333C20 17.0152 22.9848 20 26.6667 20Z" stroke="#8600C4" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M20 26.6667L20 13.3333" stroke="#8600C4" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="font-['Inter:Medium',sans-serif] font-medium text-[18px] leading-[28px] text-[#364153]">
                Доказать себе
              </p>
            </div>

            <div className="flex flex-col items-center gap-[16px]">
              <div className="bg-[#faebd0] w-[80px] h-[80px] rounded-[16px] flex items-center justify-center">
                <svg className="size-[40px]" fill="none" viewBox="0 0 40 40">
                  <path d="M20 28.3333C24.6024 28.3333 28.3333 24.6024 28.3333 20C28.3333 15.3976 24.6024 11.6667 20 11.6667C15.3976 11.6667 11.6667 15.3976 11.6667 20C11.6667 24.6024 15.3976 28.3333 20 28.3333Z" stroke="#FF7700" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M33.3333 5V11.6667" stroke="#FF7700" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M36.6667 8.33333H30" stroke="#FF7700" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6.66667 28.3333V31.6667" stroke="#FF7700" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M8.33333 30H5" stroke="#FF7700" strokeWidth="3.33333" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="font-['Inter:Medium',sans-serif] font-medium text-[18px] leading-[28px] text-[#364153]">
                Ловить кайф
              </p>
            </div>
          </div>

          {/* Slider */}
          <div className="mb-[24px]">
            <div
              ref={sliderRef}
              className="relative h-[40px] pt-[14px] cursor-pointer"
              onMouseDown={handleSliderMouseDown}
              onClick={handleSliderClick}
            >
              {/* Slider track */}
              <div className="w-full h-[12px] rounded-[33554400px] bg-gradient-to-r from-[#a135ff] to-[#ffb261]" />

              {/* Slider thumb */}
              <div
                className="absolute top-[-1px] pointer-events-none"
                style={{ left: `calc(${sliderPercentage}% - 21px)` }}
              >
                <svg className="size-[42px] drop-shadow-lg" fill="none" viewBox="0 0 46 46">
                  <circle cx="23" cy="23" fill="white" r="22" stroke="#A63BF6" strokeWidth="2" />
                </svg>
              </div>
            </div>
          </div>

          {/* Slider label */}
          <div className="text-center mb-[32px]">
            <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[24px] leading-[32px] text-[#101828]">
              {getSliderLabel()}
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[18px] leading-[28px] text-[#6a7282] mt-[8px]">
              {sliderValue.toFixed(1)}
            </p>
          </div>

          {/* Next button */}
          <button
            onClick={hasInteracted.current ? onNext : undefined}
            className={`w-full h-[68px] rounded-[16px] transition-all ${
              hasInteracted.current
                ? 'bg-[#4f39f6] hover:bg-[#4530d6] cursor-pointer'
                : 'bg-[#f3f4f6] cursor-not-allowed'
            }`}
          >
            <p className={`font-['Inter:Semi_Bold',sans-serif] font-semibold text-[18px] leading-[28px] ${
              hasInteracted.current ? 'text-white' : 'text-[#99a1af]'
            }`}>
              Далее
            </p>
          </button>
        </div>
      </div>
    </div>
  );
}

// K-6 Question Wrapper (Custom Implementation)
function K6Wrapper({
  questionIndex,
  selectedAnswer,
  onAnswerSelect,
  onBack,
  onNext,
}: {
  stepComponent?: React.ComponentType;
  questionIndex: number;
  selectedAnswer: K6Answer;
  onAnswerSelect: (answer: K6Answer) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const questions = [
    'За последние 4 недели как часто вы нервничали?',
    'За последние 4 недели как часто вы ощущали безысходность?',
    'За последние 4 недели как часто вы были беспокойны или суетливы?',
    'За последние 4 недели как часто вы чувствовали себя подавленным настолько, что ничего не могло вас приободрить?',
    'За последние 4 недели как часто вы чувствовали, что всё даётся с трудом?',
    'За последние 4 недели как часто вы ощущали свою никчемность?',
  ];

  const answers = [
    { text: 'Никогда', value: 0 },
    { text: 'Редко', value: 1 },
    { text: 'Иногда', value: 2 },
    { text: 'Часто', value: 3 },
    { text: 'Постоянно', value: 4 },
  ];

  const percentage = Math.round(((questionIndex + 1) / 6) * 100);
  const section = Math.floor(questionIndex / 2); // 0, 1, 2 for three sections

  return (
    <div className="size-full bg-[#faf7ec] flex justify-center overflow-y-auto">
      <div className="w-[672px] flex flex-col gap-[48px] px-[24px] pt-[32px] pb-[32px]">
        {/* Background decoration */}
        <div className="relative h-0">
          <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[674px] left-[-786px] opacity-50 rounded-[26843500px] top-[-39px] w-[1333px] z-[-1]">
            <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[290px] rounded-[26843500px] size-[384px] top-[-159px]" />
            <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" />
          </div>
        </div>

        {/* Top section with back button and progress */}
        <div className="relative h-[44px] w-[624px]">
          {/* Back button */}
          <button
            onClick={onBack}
            className="absolute left-0 top-0 bg-white border border-[#e5e7eb] rounded-[16px] size-[44px] flex items-center justify-center hover:bg-[#f3f4f6] transition-colors"
          >
            <svg className="size-[24px]" fill="none" viewBox="0 0 24 24">
              <path d="M15 18L9 12L15 6" stroke="#364153" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </button>

          {/* Progress indicator */}
          <div className="absolute left-0 top-[12px] h-[20px] w-[624px]">
            {/* Progress dots - centered */}
            <div className="absolute left-[256.5px] top-[9px] h-[6px] w-[112px] flex gap-[8px]">
              <div className={`h-[6px] rounded-[33554400px] w-[32px] ${section >= 0 ? 'bg-[#4f39f6]' : 'bg-[#e5e7eb]'}`} />
              <div className={`h-[6px] rounded-[33554400px] w-[32px] ${section >= 1 ? 'bg-[#4f39f6]' : 'bg-[#e5e7eb]'}`} />
              <div className={`h-[6px] rounded-[33554400px] w-[32px] ${section >= 2 ? 'bg-[#4f39f6]' : 'bg-[#e5e7eb]'}`} />
            </div>
            {/* Section text - right aligned */}
            <div className="absolute left-[601.41px] top-0 h-[20px]">
              <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] text-[#6a7282] text-[14px] whitespace-nowrap">{section + 1}/3</p>
            </div>
          </div>
        </div>

        {/* Main content card */}
        <div className="w-[624px] bg-white border border-[#f3f4f6] rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] p-[49px] pb-[32px]">
          {/* Question progress */}
          <div className="flex justify-between mb-[32px]">
            <p className="font-['Inter:Medium',sans-serif] font-medium text-[14px] leading-[20px] text-[#4a5565]">
              Вопрос {questionIndex + 1} из 6
            </p>
            <p className="font-['Inter:Medium',sans-serif] font-medium text-[14px] leading-[20px] text-[#4f39f6]">
              {percentage}%
            </p>
          </div>

          {/* Progress bar */}
          <div className="h-[8px] bg-[#f3f4f6] rounded-[33554400px] mb-[32px] overflow-hidden">
            <div
              className="h-full bg-[#4f39f6] rounded-[33554400px] transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>

          {/* Question text */}
          <h1 className="font-['Inter:Regular',sans-serif] font-normal text-[36px] leading-[48px] text-[#101828] text-center mb-[48px]">
            {questionIndex === 0 && <>За последние 4 недели как часто вы <span className="font-semibold">нервничали?</span></>}
            {questionIndex === 1 && <>За последние 4 недели как часто вы <span className="font-semibold">ощущали безысходность?</span></>}
            {questionIndex === 2 && <>За последние 4 недели как часто вы <span className="font-semibold">были беспокойны или суетливы?</span></>}
            {questionIndex === 3 && <>За последние 4 недели как часто вы <span className="font-semibold">чувствовали себя подавленным настолько, что ничего не могло вас приободрить?</span></>}
            {questionIndex === 4 && <>За последние 4 недели как часто вы <span className="font-semibold">чувствовали, что всё даётся с трудом?</span></>}
            {questionIndex === 5 && <>За последние 4 недели как часто вы <span className="font-semibold">ощущали свою никчемность?</span></>}
          </h1>

          {/* Answer options */}
          <div className="flex flex-col gap-[16px] mb-[32px]">
            {answers.map((answer) => (
              <button
                key={answer.value}
                onClick={() => onAnswerSelect(answer.value as K6Answer)}
                className={`h-[78px] rounded-[16px] border transition-all ${
                  selectedAnswer === answer.value
                    ? 'bg-[rgba(79,57,246,0.7)] border-[#4f39f6]'
                    : 'bg-[rgba(255,255,255,0.1)] border-[#e5e7eb] hover:bg-[rgba(79,57,246,0.05)] hover:border-[#4f39f6]'
                }`}
              >
                <div className="flex items-center justify-between px-[25px]">
                  <p className={`font-['Inter:Medium',sans-serif] font-medium text-[18px] leading-[28px] ${
                    selectedAnswer === answer.value ? 'text-white' : 'text-[#364153]'
                  }`}>
                    {answer.text}
                  </p>
                  <div className="size-[24px] rounded-full border-2 flex items-center justify-center transition-all"
                       style={{
                         borderColor: selectedAnswer === answer.value ? 'white' : '#d1d5dc',
                         backgroundColor: selectedAnswer === answer.value ? 'white' : 'transparent'
                       }}>
                    {selectedAnswer === answer.value && (
                      <div className="size-[12px] rounded-full bg-[#4f39f6]" />
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Next button */}
          <button
            onClick={selectedAnswer !== null ? onNext : undefined}
            disabled={selectedAnswer === null}
            className={`w-full h-[68px] rounded-[16px] transition-all ${
              selectedAnswer !== null
                ? 'bg-[#4f39f6] hover:bg-[#4530d6] cursor-pointer'
                : 'bg-[#f3f4f6] cursor-not-allowed'
            }`}
          >
            <p className={`font-['Inter:Semi_Bold',sans-serif] font-semibold text-[18px] leading-[28px] ${
              selectedAnswer !== null ? 'text-white' : 'text-[#99a1af]'
            }`}>
              Следующий вопрос
            </p>
          </button>
        </div>
      </div>
    </div>
  );
}

// Step 3 Wrapper - Locus of Control (Custom Implementation)
function Step3Wrapper({
  selectedChoice,
  onChoiceSelect,
  onBack,
  onComplete,
}: {
  selectedChoice: LocusChoice;
  onChoiceSelect: (choice: LocusChoice) => void;
  onBack: () => void;
  onComplete: () => void;
}) {
  return (
    <div className="size-full bg-[#faf7ec] flex justify-center overflow-y-auto">
      <div className="w-[672px] flex flex-col gap-[48px] px-[24px] pt-[32px] pb-[32px]">
        {/* Background decoration */}
        <div className="relative h-0">
          <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[674px] left-[-786px] opacity-50 rounded-[26843500px] top-[-39px] w-[1333px] z-[-1]">
            <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[290px] rounded-[26843500px] size-[384px] top-[-159px]" />
            <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" />
          </div>
        </div>

        {/* Top section with back button and progress */}
        <div className="relative h-[44px] w-[624px]">
          {/* Back button */}
          <button
            onClick={onBack}
            className="absolute left-0 top-0 bg-white border border-[#e5e7eb] rounded-[16px] size-[44px] flex items-center justify-center hover:bg-[#f3f4f6] transition-colors"
          >
            <svg className="size-[24px]" fill="none" viewBox="0 0 24 24">
              <path d="M15 18L9 12L15 6" stroke="#364153" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </button>

          {/* Progress indicator */}
          <div className="absolute left-0 top-[12px] h-[20px] w-[624px]">
            {/* Progress dots - centered */}
            <div className="absolute left-[256.5px] top-[9px] h-[6px] w-[112px] flex gap-[8px]">
              <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] w-[32px]" />
              <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] w-[32px]" />
              <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] w-[32px]" />
            </div>
            {/* Section text - right aligned */}
            <div className="absolute left-[601.41px] top-0 h-[20px]">
              <p className="font-['Inter:Medium',sans-serif] font-medium leading-[20px] text-[#6a7282] text-[14px] whitespace-nowrap">3/3</p>
            </div>
          </div>
        </div>

        {/* Main content card */}
        <div className="w-[624px] bg-white border border-[#f3f4f6] rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)] p-[49px] pb-[32px]">
          {/* Question text */}
          <h1 className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[48px] leading-[60px] text-[#101828] text-center mb-[24px]">
            Представь, что ты неделю тренировался, а вес или объёмы не изменились. Какая мысль первой приходит в голову?
          </h1>

          {/* Choice cards */}
          <div className="flex gap-[20px] mb-[32px]">
            {/* Internal card */}
            <button
              onClick={() => onChoiceSelect('internal')}
              className={`w-[302px] h-[310.25px] bg-white border-2 rounded-[24px] p-[24px] flex flex-col transition-all ${
                selectedChoice === 'internal'
                  ? 'border-[#B139F6] shadow-[0_4px_12px_rgba(177,57,246,0.3)]'
                  : 'border-[#e5e7eb] hover:border-[#B139F6] hover:shadow-[0_2px_8px_rgba(177,57,246,0.2)]'
              }`}
            >
              <div className="bg-[#f1e0ff] w-[56px] h-[56px] rounded-[16px] flex items-center justify-center mb-[16px]">
                <svg className="size-[28px]" fill="none" viewBox="0 0 28 28">
                  <path d="M19.8333 19.8333L24.5 24.5M22.1667 12.8333C22.1667 18.0381 18.0381 22.1667 12.8333 22.1667C7.62857 22.1667 3.5 18.0381 3.5 12.8333C3.5 7.62857 7.62857 3.5 12.8333 3.5C18.0381 3.5 22.1667 7.62857 22.1667 12.8333Z" stroke="#B139F6" strokeWidth="2.33333" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="font-['Inter:Medium',sans-serif] font-medium text-[18px] leading-[29.25px] text-[#364153] text-left flex-1">
                Наверное, я что-то делаю не так в питании или технике. Надо разобраться и скорректировать.
              </p>
              <div className="flex justify-end">
                <div className="size-[24px] rounded-full border-2 flex items-center justify-center transition-all"
                     style={{
                       borderColor: selectedChoice === 'internal' ? '#B139F6' : '#d1d5dc',
                       backgroundColor: selectedChoice === 'internal' ? '#B139F6' : 'transparent'
                     }}>
                  {selectedChoice === 'internal' && (
                    <div className="size-[12px] rounded-full bg-white" />
                  )}
                </div>
              </div>
            </button>

            {/* External card */}
            <button
              onClick={() => onChoiceSelect('external')}
              className={`w-[302px] h-[310.25px] bg-white border-2 rounded-[24px] p-[24px] flex flex-col transition-all ${
                selectedChoice === 'external'
                  ? 'border-[#009966] shadow-[0_4px_12px_rgba(0,153,102,0.3)]'
                  : 'border-[#e5e7eb] hover:border-[#009966] hover:shadow-[0_2px_8px_rgba(0,153,102,0.2)]'
              }`}
            >
              <div className="bg-[#d0fae5] w-[56px] h-[56px] rounded-[16px] flex items-center justify-center mb-[16px]">
                <svg className="size-[28px]" fill="none" viewBox="0 0 28 28">
                  <path d="M14 23.3333C19.1547 23.3333 23.3333 19.1547 23.3333 14C23.3333 8.8453 19.1547 4.66666 14 4.66666C8.8453 4.66666 4.66666 8.8453 4.66666 14C4.66666 19.1547 8.8453 23.3333 14 23.3333Z" stroke="#009966" strokeWidth="2.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M14 18.6667V14" stroke="#009966" strokeWidth="2.33333" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M14 9.33334H14.0117" stroke="#009966" strokeWidth="2.33333" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="font-['Inter:Medium',sans-serif] font-medium text-[18px] leading-[29.25px] text-[#364153] text-left flex-1">
                Организм просто так устроен — генетика, метаболизм. Иногда прогресса нет, и это нормально.
              </p>
              <div className="flex justify-end">
                <div className="size-[24px] rounded-full border-2 flex items-center justify-center transition-all"
                     style={{
                       borderColor: selectedChoice === 'external' ? '#009966' : '#d1d5dc',
                       backgroundColor: selectedChoice === 'external' ? '#009966' : 'transparent'
                     }}>
                  {selectedChoice === 'external' && (
                    <div className="size-[12px] rounded-full bg-white" />
                  )}
                </div>
              </div>
            </button>
          </div>

          {/* Complete button */}
          <button
            onClick={selectedChoice !== null ? onComplete : undefined}
            disabled={selectedChoice === null}
            className={`w-full h-[68px] rounded-[16px] transition-all ${
              selectedChoice !== null
                ? 'bg-[#4f39f6] hover:bg-[#4530d6] cursor-pointer'
                : 'bg-[#f3f4f6] cursor-not-allowed'
            }`}
          >
            <p className={`font-['Inter:Semi_Bold',sans-serif] font-semibold text-[18px] leading-[28px] ${
              selectedChoice !== null ? 'text-white' : 'text-[#99a1af]'
            }`}>
              Завершить
            </p>
          </button>
        </div>
      </div>
    </div>
  );
}
