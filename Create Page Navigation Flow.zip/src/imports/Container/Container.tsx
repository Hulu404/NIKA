function Container2() {
  return <div className="absolute bg-[#7c86ff] h-[6px] left-0 rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container3() {
  return <div className="absolute bg-[#4f39f6] h-[6px] left-[40px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container4() {
  return <div className="absolute bg-[#e5e7eb] h-[6px] left-[80px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container1() {
  return (
    <div className="absolute h-[6px] left-[256.5px] top-[9px] w-[112px]" data-name="Container">
      <Container2 />
      <Container3 />
      <Container4 />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[20px] left-[601.41px] top-0 w-[22.594px]" data-name="Text">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-0 whitespace-nowrap">2/3</p>
    </div>
  );
}

function Container5() {
  return <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[293px] rounded-[26843500px] size-[384px] top-[-159px]" data-name="Container" />;
}

function Container6() {
  return <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" data-name="Container" />;
}

function Component() {
  return (
    <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[453px] left-[-449.5px] opacity-50 rounded-[26843500px] top-[313.5px] w-[954px]" data-name="цвет на фон">
      <Container5 />
      <Container6 />
    </div>
  );
}

export default function Container() {
  return (
    <div className="relative size-full" data-name="Container">
      <Container1 />
      <Text />
      <Component />
    </div>
  );
}