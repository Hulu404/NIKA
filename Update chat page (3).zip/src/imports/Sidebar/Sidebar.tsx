import svgPaths from "./svg-7buvzsrtrd";

function Text() {
  return (
    <div className="h-[20px] relative shrink-0 w-[11.063px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[20px] left-0 text-[14px] text-white top-[-1.2px] whitespace-nowrap">N</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-gradient-to-b from-[#f6b044] relative rounded-[14px] shadow-[0px_10px_15px_0px_rgba(0,0,0,0.1),0px_4px_6px_0px_rgba(0,0,0,0.1)] shrink-0 size-[32px] to-[#f39c12]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pr-[0.012px] relative size-full">
        <Text />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="flex-[1_0_0] h-[24px] min-h-px min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[24px] left-0 text-[#101828] text-[16px] top-[-2.2px] whitespace-nowrap">NIKA</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[32px] relative shrink-0 w-[81.463px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Container2 />
        <Text1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pr-[189.738px] relative size-full">
          <Container1 />
        </div>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M4.16667 10H15.8333" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
          <path d="M10 4.16667V15.8333" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
        </g>
      </svg>
    </div>
  );
}

function ChatSidebar1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[80.838px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-[40.5px] text-[16px] text-center text-white top-[-2.2px] whitespace-nowrap">Новый чат</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-gradient-to-b from-[#f6b044] h-[52px] relative rounded-[16px] shadow-[0px_10px_15px_0px_rgba(246,176,68,0.2),0px_4px_6px_0px_rgba(246,176,68,0.2)] shrink-0 to-[#f39c12] w-full" data-name="Button">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex gap-[10px] items-center justify-center pr-[0.013px] relative size-full">
          <Icon />
          <ChatSidebar1 />
        </div>
      </div>
    </div>
  );
}

function ChatSidebar() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[156.8px] items-start left-0 pb-[0.8px] pt-[24px] px-[24px] top-0 w-[319.2px]" data-name="ChatSidebar">
      <div aria-hidden="true" className="absolute border-[rgba(0,0,0,0.05)] border-b-[0.8px] border-solid inset-0 pointer-events-none" />
      <Container />
      <Button />
    </div>
  );
}

function TextInput() {
  return (
    <div className="absolute bg-white h-[41.6px] left-0 rounded-[14px] top-0 w-[271.2px]" data-name="Text Input">
      <div className="content-stretch flex items-center overflow-clip pl-[44px] pr-[16px] py-[10px] relative rounded-[inherit] size-full">
        <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[#99a1af] text-[14px] whitespace-nowrap">Поиск...</p>
      </div>
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_-1px_rgba(0,0,0,0.1)]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute left-[14px] size-[18px] top-[11.8px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d="M15.75 15.75L12.495 12.495" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
          <path d={svgPaths.p126da180} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
        </g>
      </svg>
    </div>
  );
}

function ChatSidebar2() {
  return (
    <div className="absolute h-[41.6px] left-[24px] top-[172.8px] w-[271.2px]" data-name="ChatSidebar">
      <TextInput />
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_1_206)" id="Icon">
          <path d="M7 3.5V7L9.33333 8.16667" id="Vector" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.45833" />
          <path d={svgPaths.pc012c00} id="Vector_2" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.45833" />
        </g>
        <defs>
          <clipPath id="clip0_1_206">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[15.988px] relative shrink-0 w-[68.525px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#6a7282] text-[12px] tracking-[0.6px] uppercase whitespace-nowrap">Недавние</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[15.988px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center pl-[12px] relative size-full">
          <Icon2 />
          <Heading />
        </div>
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">План тренировок на неделю</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="content-stretch flex h-[15.988px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="flex-[1_0_0] font-['Arimo:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px relative text-[#99a1af] text-[12px]">2ч назад</p>
    </div>
  );
}

function ChatSidebar4() {
  return (
    <div className="flex-[1_0_0] h-[37.987px] min-h-px min-w-px relative" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <Paragraph />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[59.588px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="content-stretch flex items-start pb-[0.8px] pt-[10.8px] px-[12.8px] relative size-full">
        <ChatSidebar4 />
      </div>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Советы по питанию</p>
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="content-stretch flex h-[15.988px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="flex-[1_0_0] font-['Arimo:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px relative text-[#99a1af] text-[12px]">5ч назад</p>
    </div>
  );
}

function ChatSidebar5() {
  return (
    <div className="flex-[1_0_0] h-[37.987px] min-h-px min-w-px relative" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <Paragraph2 />
        <Paragraph3 />
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[59.588px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="content-stretch flex items-start pb-[0.8px] pt-[10.8px] px-[12.8px] relative size-full">
        <ChatSidebar5 />
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Упражнения для спины</p>
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="content-stretch flex h-[15.988px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="flex-[1_0_0] font-['Arimo:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px relative text-[#99a1af] text-[12px]">Вчера</p>
    </div>
  );
}

function ChatSidebar6() {
  return (
    <div className="flex-[1_0_0] h-[37.987px] min-h-px min-w-px relative" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <Paragraph4 />
        <Paragraph5 />
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="h-[59.588px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="content-stretch flex items-start pb-[0.8px] pt-[10.8px] px-[12.8px] relative size-full">
        <ChatSidebar6 />
      </div>
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Восстановление после бега</p>
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="content-stretch flex h-[15.988px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="flex-[1_0_0] font-['Arimo:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px relative text-[#99a1af] text-[12px]">2 дня назад</p>
    </div>
  );
}

function ChatSidebar7() {
  return (
    <div className="flex-[1_0_0] h-[37.987px] min-h-px min-w-px relative" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <Paragraph6 />
        <Paragraph7 />
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="h-[59.588px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="content-stretch flex items-start pb-[0.8px] pt-[10.8px] px-[12.8px] relative size-full">
        <ChatSidebar7 />
      </div>
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] h-[250.35px] items-start relative shrink-0 w-full" data-name="Container">
      <Button1 />
      <Button2 />
      <Button3 />
      <Button4 />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[278.337px] items-start relative shrink-0 w-full" data-name="Container">
      <Container4 />
      <Container5 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute content-stretch flex h-[15.988px] items-start left-[12px] top-0 w-[256px]" data-name="Heading 3">
      <p className="flex-[1_0_0] font-['Arimo:Bold',sans-serif] font-bold leading-[16px] min-h-px min-w-px relative text-[#6a7282] text-[12px] tracking-[0.6px] uppercase">Меню</p>
    </div>
  );
}

function ChatSidebar8() {
  return (
    <div className="h-[20px] relative shrink-0 w-[116.287px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Трекер прогресса</p>
      </div>
    </div>
  );
}

function ChatSidebar9() {
  return (
    <div className="bg-[rgba(246,176,68,0.2)] h-[19.988px] relative rounded-[26843500px] shrink-0 w-[52.163px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[2px] relative size-full">
        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#f6b044] text-[12px] whitespace-nowrap">Новое</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[12.8px] py-[0.8px] relative size-full">
          <ChatSidebar8 />
          <ChatSidebar9 />
        </div>
      </div>
    </div>
  );
}

function ChatSidebar10() {
  return (
    <div className="h-[20px] relative shrink-0 w-[82.675px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Упражнения</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[184.525px] py-[0.8px] relative size-full">
          <ChatSidebar10 />
        </div>
      </div>
    </div>
  );
}

function ChatSidebar11() {
  return (
    <div className="h-[20px] relative shrink-0 w-[115.85px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Дневник питания</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[151.35px] py-[0.8px] relative size-full">
          <ChatSidebar11 />
        </div>
      </div>
    </div>
  );
}

function ChatSidebar12() {
  return (
    <div className="h-[20px] relative shrink-0 w-[32.213px]" data-name="ChatSidebar">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">FAQs</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[234.988px] py-[0.8px] relative size-full">
          <ChatSidebar12 />
        </div>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[178.4px] items-start left-0 top-[27.99px] w-[280px]" data-name="Container">
      <Button5 />
      <Button6 />
      <Button7 />
      <Button8 />
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[206.387px] relative shrink-0 w-full" data-name="Container">
      <Heading1 />
      <Container7 />
    </div>
  );
}

function ChatSidebar3() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[320px] items-start left-0 overflow-clip pl-[12px] pr-[27.2px] top-[230.4px] w-[319.2px]" data-name="ChatSidebar">
      <Container3 />
      <Container6 />
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d={svgPaths.p2802f40} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
          <path d={svgPaths.p254f3200} id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[20px] relative shrink-0 w-[71.213px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[36.5px] text-[#4a5565] text-[14px] text-center top-[-1.2px] whitespace-nowrap">Настройки</p>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <div className="h-[40px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center pl-[12px] relative size-full">
          <Icon3 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Icon">
          <path d="M12 12.75L15.75 9L12 5.25" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
          <path d="M15.75 9H6.75" id="Vector_2" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
          <path d={svgPaths.p3d8d0000} id="Vector_3" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[20px] relative shrink-0 w-[41.938px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[21px] text-[#4a5565] text-[14px] text-center top-[-1.2px] whitespace-nowrap">Выйти</p>
      </div>
    </div>
  );
}

function Button10() {
  return (
    <div className="h-[40px] relative rounded-[14px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center pl-[12px] relative size-full">
          <Icon4 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function ChatSidebar13() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[4px] h-[116.8px] items-start left-0 pt-[16.8px] px-[16px] top-[550.4px] w-[319.2px]" data-name="ChatSidebar">
      <div aria-hidden="true" className="absolute border-[rgba(0,0,0,0.05)] border-solid border-t-[0.8px] inset-0 pointer-events-none" />
      <Button9 />
      <Button10 />
    </div>
  );
}

export default function Sidebar() {
  return (
    <div className="bg-[rgba(255,255,255,0.8)] border-[rgba(0,0,0,0.05)] border-r-[0.8px] border-solid relative size-full" data-name="Sidebar">
      <ChatSidebar />
      <ChatSidebar2 />
      <ChatSidebar3 />
      <ChatSidebar13 />
    </div>
  );
}