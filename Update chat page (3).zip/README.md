
  # Update chat page

  This is a code bundle for Update chat page. The original project is available at https://www.figma.com/design/yGQyvZVhvv0Rp3vkTEGqGT/Update-chat-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  