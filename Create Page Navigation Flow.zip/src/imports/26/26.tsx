function Container3() {
  return <div className="absolute bg-[#7c86ff] h-[6px] left-0 rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container4() {
  return <div className="absolute bg-[#4f39f6] h-[6px] left-[40px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container5() {
  return <div className="absolute bg-[#e5e7eb] h-[6px] left-[80px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container7() {
  return <div className="absolute bg-[#7c86ff] h-[6px] left-0 rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container8() {
  return <div className="absolute bg-[#4f39f6] h-[6px] left-[40px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container9() {
  return <div className="absolute bg-[#e5e7eb] h-[6px] left-[80px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container10() {
  return <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[293px] rounded-[26843500px] size-[384px] top-[-159px]" data-name="Container" />;
}

function Container11() {
  return <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" data-name="Container" />;
}

function Component() {
  return (
    <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[453px] left-[-751px] opacity-50 rounded-[26843500px] top-[-60px] w-[954px]" data-name="цвет на фон">
      <Container10 />
      <Container11 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute h-[6px] left-0 top-0 w-[112px]" data-name="Container">
      <Container7 />
      <Container8 />
      <Container9 />
      <Component />
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[6px] left-[256.5px] top-[9px] w-[112px]" data-name="Container">
      <Container3 />
      <Container4 />
      <Container5 />
      <Container6 />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[20px] left-[601.41px] top-0 w-[22.594px]" data-name="Text">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-0 whitespace-nowrap">2/3</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[15px] size-[24px] top-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_167)" id="Icon">
          <path d="M9 12L3 6L9 0" id="Vector" stroke="var(--stroke-0, #364153)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_167">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid left-[0.5px] rounded-[16px] size-[44px] top-[-10px]" data-name="Button">
      <Icon />
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container2 />
        <Text />
        <Button />
        <div className="absolute bg-white h-[803px] left-[-34.5px] rounded-[38px] top-[48px] w-[693px]" />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[95.5px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#4a5565] text-[14px] top-0 whitespace-nowrap">Вопрос 6 из 6</p>
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[20px] relative shrink-0 w-[37.797px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#4f39f6] text-[14px] top-0 whitespace-nowrap">100%</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex h-[20px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Text1 />
      <Text2 />
    </div>
  );
}

function Container15() {
  return <div className="bg-[#4f39f6] h-[6px] rounded-[33554400px] shrink-0 w-full" data-name="Container" />;
}

function Container14() {
  return (
    <div className="bg-[#f3f4f6] content-stretch flex flex-col h-[6px] items-start overflow-clip relative rounded-[33554400px] shrink-0 w-full" data-name="Container">
      <Container15 />
    </div>
  );
}

function K6Questionnaire() {
  return (
    <div className="h-[38px] relative shrink-0 w-[624px]" data-name="K6Questionnaire">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[12px] items-start relative size-full">
        <Container13 />
        <Container14 />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[90px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[0] left-[312px] not-italic text-[#101828] text-[0px] text-center top-[-1px] w-[624px]">
        <span className="leading-[45px] text-[36px]">{`За последние 4 недели как часто вы `}</span>
        <span className="font-['Inter:Black',sans-serif] font-black leading-[45px] text-[36px]">ощущали свою никчемность?</span>
      </p>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[28px] relative shrink-0 w-[73.922px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Никогда</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute content-stretch flex h-[28px] items-center justify-between left-[24px] top-[24px] w-[574px]" data-name="Container">
      <Text3 />
      <Container19 />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[#e5e7eb] border-solid h-[78px] left-0 rounded-[16px] top-0 w-[624px]" data-name="Button">
      <Container18 />
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[28px] relative shrink-0 w-[53.797px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Редко</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute content-stretch flex h-[28px] items-center justify-between left-[24px] top-[24px] w-[574px]" data-name="Container">
      <Text4 />
      <Container21 />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[#e5e7eb] border-solid h-[78px] left-0 rounded-[16px] top-[94px] w-[624px]" data-name="Button">
      <Container20 />
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[28px] relative shrink-0 w-[64.484px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Иногда</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex h-[28px] items-center justify-between left-[24px] top-[24px] w-[574px]" data-name="Container">
      <Text5 />
      <Container23 />
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[#e5e7eb] border-solid h-[78px] left-0 rounded-[16px] top-[188px] w-[624px]" data-name="Button">
      <Container22 />
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[28px] relative shrink-0 w-[96.406px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28px] left-0 not-italic text-[#364153] text-[18px] top-0 whitespace-nowrap">Постоянно</p>
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container24() {
  return (
    <div className="absolute content-stretch flex h-[28px] items-center justify-between left-[24px] top-[24px] w-[574px]" data-name="Container">
      <Text6 />
      <Container25 />
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.1)] border border-[#e5e7eb] border-solid h-[78px] left-0 rounded-[16px] top-[374px] w-[624px]" data-name="Button">
      <Container24 />
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[28.56px] relative shrink-0 w-[53.04px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[28.56px] left-[-0.22px] not-italic text-[18.36px] text-white top-0 whitespace-nowrap">Часто</p>
      </div>
    </div>
  );
}

function Container28() {
  return <div className="bg-[#4f39f6] rounded-[34225488px] shrink-0 size-[12.24px]" data-name="Container" />;
}

function Container27() {
  return (
    <div className="bg-white relative rounded-[34225488px] shrink-0 size-[24.48px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[2.04px] border-solid border-white inset-0 pointer-events-none rounded-[34225488px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[6.12px] py-[2.04px] relative size-full">
        <Container28 />
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="absolute content-stretch flex h-[28.56px] items-center justify-between left-[24.48px] pl-[0.223px] top-[24.48px] w-[587.52px]" data-name="Container">
      <Text7 />
      <Container27 />
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[rgba(79,57,246,0.8)] h-[77.52px] left-[-6.24px] rounded-[16.32px] top-[281.24px] w-[636.48px]" data-name="Button">
      <Container26 />
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[452px] relative shrink-0 w-full" data-name="Container">
      <Button1 />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[622px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[48px] items-start relative size-full">
        <Heading />
        <Container17 />
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-[#4f39f6] flex-[556_0_0] h-[68px] min-w-px relative rounded-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-[312px] not-italic text-[18px] text-center text-white top-[20px] whitespace-nowrap">Далее</p>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[68px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <Button6 />
      </div>
    </div>
  );
}

function K6Questionnaire1() {
  return (
    <div className="flex-[690_0_0] min-h-px relative w-[624px]" data-name="K6Questionnaire">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center relative size-full">
        <Container16 />
        <Container29 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="flex-[760_0_0] min-h-px relative w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[32px] items-start relative size-full">
        <K6Questionnaire />
        <K6Questionnaire1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="h-[892px] relative shrink-0 w-[672px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[48px] items-start px-[24px] py-[32px] relative size-full">
        <Container1 />
        <Container12 />
      </div>
    </div>
  );
}

function OnboardingWizard() {
  return (
    <div className="bg-[#faf7ec] relative shrink-0 w-full" data-name="OnboardingWizard">
      <div className="content-stretch flex flex-col items-start pl-[425.5px] relative size-full">
        <Container />
      </div>
    </div>
  );
}

function Body() {
  return (
    <div className="content-stretch flex flex-col h-[877px] items-start relative shrink-0 w-full" data-name="Body">
      <OnboardingWizard />
    </div>
  );
}

export default function Component1() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start pt-[-15px] relative size-full" data-name="2-6">
      <Body />
    </div>
  );
}