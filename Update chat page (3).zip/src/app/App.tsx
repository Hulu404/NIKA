import { useState } from 'react';
import svgPaths from '../imports/НовыйДиалог-1/svg-ft5n8ade1c';
import sidebarSvgPaths from '../imports/Sidebar/svg-7buvzsrtrd';
import imgImageNika from '../imports/НовыйДиалог-1/23ab7528e0cbc70eec16bb3be67f5d33b9e64433.png';
import Mascot from '../imports/Img47381Vectorized-1/Img47381Vectorized-21-110';
import { UserProfile } from './components/UserProfile';
import { SubscriptionButton } from './components/SubscriptionButton';
import { PremiumPage } from './components/PremiumPage';

export default function App() {
  const [userName] = useState('Анна А.');
  const [hasSubscription] = useState(false);
  const [showPremiumBanner, setShowPremiumBanner] = useState(true);
  const [showPremiumPage, setShowPremiumPage] = useState(false);

  const handleSubscriptionClick = () => {
    setShowPremiumPage(true);
  };

  const handleCloseBanner = () => {
    setShowPremiumBanner(false);
  };

  const handleClosePremiumPage = () => {
    setShowPremiumPage(false);
  };

  return (
    <>
      {showPremiumPage && <PremiumPage onClose={handleClosePremiumPage} />}
      <div className="relative w-screen h-screen overflow-hidden" style={{ backgroundImage: "linear-gradient(rgb(250, 250, 250) 0%, rgb(255, 255, 255) 50%, rgb(245, 245, 245) 100%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      {/* Background Blurs */}
      <div className="absolute bg-gradient-to-b from-[#fafafa] h-full left-0 to-[#f5f5f5] top-0 via-1/2 via-white w-full">
        <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[289.8px] opacity-50 rounded-[26843500px] size-[384px] top-0" />
        <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[485.4px] rounded-[26843500px] size-[384px] top-[283.2px]" />
      </div>

      {/* Sidebar */}
      <div className="absolute bg-[rgba(255,255,255,0.8)] backdrop-blur-[20px] border-[rgba(0,0,0,0.05)] border-r-[0.8px] border-solid h-full left-0 top-0 w-[320px]">
        {/* User Profile Section */}
        <div className="border-[rgba(0,0,0,0.05)] border-b-[0.8px] border-solid h-[156.8px] px-[24px] pt-[24px] pb-[24px] flex flex-col gap-[16px]">
          <div className="flex items-center gap-[12px]">
            <UserProfile name={userName} hasActiveSubscription={hasSubscription} />
            <div className="flex-1">
              <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[24px] text-[#101828] text-[16px]">
                {userName}
              </p>
            </div>
          </div>

          {/* New Chat Button */}
          <button className="bg-gradient-to-b from-[#f6b044] to-[#f39c12] h-[52px] rounded-[16px] shadow-[0px_10px_15px_0px_rgba(246,176,68,0.2),0px_4px_6px_0px_rgba(246,176,68,0.2)] flex items-center justify-center gap-[10px] transition-all duration-300 hover:shadow-[0px_12px_20px_0px_rgba(246,176,68,0.3)] hover:scale-[1.02] active:scale-[0.98]">
            <svg className="size-[20px]" fill="none" viewBox="0 0 20 20">
              <g>
                <path d="M4.16667 10H15.8333" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
                <path d="M10 4.16667V15.8333" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
              </g>
            </svg>
            <span className="font-['Arimo:Regular',sans-serif] font-normal leading-[24px] text-[16px] text-white">
              Новый чат
            </span>
          </button>
        </div>

        {/* Search */}
        <div className="px-[24px] pt-[16px]">
          <div className="relative bg-white h-[41.6px] rounded-[14px] border-[0.8px] border-[rgba(0,0,0,0.1)] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1)]">
            <input
              type="text"
              placeholder="Поиск..."
              className="w-full h-full bg-transparent pl-[44px] pr-[16px] py-[10px] font-['Arimo:Regular',sans-serif] text-[14px] text-[#4a5565] placeholder:text-[#99a1af] outline-none rounded-[14px]"
            />
            <svg className="absolute left-[14px] top-[11.8px] size-[18px]" fill="none" viewBox="0 0 18 18">
              <g>
                <path d="M15.75 15.75L12.495 12.495" stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                <path d={svgPaths.p126da180} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
              </g>
            </svg>
          </div>
        </div>

        {/* Recent Chats and Menu */}
        <div className="absolute content-stretch flex flex-col gap-[24px] h-[320px] items-start left-0 overflow-clip pl-[12px] pr-[27.2px] top-[230.4px] w-[319.2px]">
          {/* Recent Chats */}
          <div className="content-stretch flex flex-col gap-[12px] h-[278.337px] items-start relative shrink-0 w-full">
            <div className="h-[15.988px] relative shrink-0 w-full">
              <div className="flex flex-row items-center size-full">
                <div className="content-stretch flex gap-[8px] items-center pl-[12px] relative size-full">
                  <svg className="size-[14px]" fill="none" viewBox="0 0 14 14">
                    <g clipPath="url(#clip0_1_206)">
                      <path d="M7 3.5V7L9.33333 8.16667" stroke="#6A7282" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.45833" />
                      <path d={sidebarSvgPaths.pc012c00} stroke="#6A7282" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.45833" />
                    </g>
                    <defs>
                      <clipPath id="clip0_1_206">
                        <rect fill="white" height="14" width="14" />
                      </clipPath>
                    </defs>
                  </svg>
                  <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#6a7282] text-[12px] tracking-[0.6px] uppercase whitespace-nowrap">Недавние</p>
                </div>
              </div>
            </div>
            <div className="content-stretch flex flex-col gap-[4px] h-[250.35px] items-start relative shrink-0 w-full">
              {[
                { title: 'План тренировок на неделю', time: '2ч назад' },
                { title: 'Советы по питанию', time: '5ч назад' },
                { title: 'Упражнения для спины', time: 'Вчера' },
                { title: 'Восстановление после бега', time: '2 дня назад' }
              ].map((chat, i) => (
                <div key={i} className="h-[59.588px] relative rounded-[14px] shrink-0 w-full">
                  <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
                  <div className="content-stretch flex items-start pb-[0.8px] pt-[10.8px] px-[12.8px] relative size-full">
                    <div className="flex-[1_0_0] h-[37.987px] min-h-px min-w-px relative">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
                        <div className="h-[20px] overflow-clip relative shrink-0 w-full">
                          <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">{chat.title}</p>
                        </div>
                        <div className="content-stretch flex h-[15.988px] items-start relative shrink-0 w-full">
                          <p className="flex-[1_0_0] font-['Arimo:Regular',sans-serif] font-normal leading-[16px] min-h-px min-w-px relative text-[#99a1af] text-[12px]">{chat.time}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Menu Section */}
          <div className="h-[206.387px] relative shrink-0 w-full">
            <div className="absolute content-stretch flex h-[15.988px] items-start left-[12px] top-0 w-[256px]">
              <p className="flex-[1_0_0] font-['Arimo:Bold',sans-serif] font-bold leading-[16px] min-h-px min-w-px relative text-[#6a7282] text-[12px] tracking-[0.6px] uppercase">Меню</p>
            </div>
            <div className="absolute content-stretch flex flex-col gap-[4px] h-[178.4px] items-start left-0 top-[27.99px] w-[280px]">
              {/* Трекер прогресса */}
              <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full">
                <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center justify-between px-[12.8px] py-[0.8px] relative size-full">
                    <div className="h-[20px] relative shrink-0 w-[116.287px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Трекер прогресса</p>
                      </div>
                    </div>
                    <div className="bg-[rgba(246,176,68,0.2)] h-[19.988px] relative rounded-[26843500px] shrink-0 w-[52.163px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[2px] relative size-full">
                        <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[16px] relative shrink-0 text-[#f6b044] text-[12px] whitespace-nowrap">Новое</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* Упражнения */}
              <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full">
                <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[184.525px] py-[0.8px] relative size-full">
                    <div className="h-[20px] relative shrink-0 w-[82.675px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Упражнения</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* Дневник питания */}
              <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full">
                <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[151.35px] py-[0.8px] relative size-full">
                    <div className="h-[20px] relative shrink-0 w-[115.85px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">Дневник питания</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* FAQs */}
              <div className="h-[41.6px] relative rounded-[14px] shrink-0 w-full">
                <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[14px]" />
                <div className="flex flex-row items-center size-full">
                  <div className="content-stretch flex items-center justify-between pl-[12.8px] pr-[234.988px] py-[0.8px] relative size-full">
                    <div className="h-[20px] relative shrink-0 w-[32.213px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                        <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#4a5565] text-[14px] top-[-1.2px] whitespace-nowrap">FAQs</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Settings and Logout Section */}
        <div className="absolute content-stretch flex flex-col gap-[4px] h-[116.8px] items-start left-0 pt-[16.8px] px-[16px] top-[550.4px] w-[319.2px]">
          <div aria-hidden="true" className="absolute border-[rgba(0,0,0,0.05)] border-solid border-t-[0.8px] inset-0 pointer-events-none" />
          {/* Настройки */}
          <div className="h-[40px] relative rounded-[14px] shrink-0 w-full">
            <div className="flex flex-row items-center size-full">
              <div className="content-stretch flex gap-[12px] items-center pl-[12px] relative size-full">
                <svg className="relative shrink-0 size-[18px]" fill="none" viewBox="0 0 18 18">
                  <g>
                    <path d={sidebarSvgPaths.p2802f40} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                    <path d={sidebarSvgPaths.p254f3200} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                  </g>
                </svg>
                <div className="h-[20px] relative shrink-0 w-[71.213px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[36.5px] text-[#4a5565] text-[14px] text-center top-[-1.2px] whitespace-nowrap">Настройки</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Выйти */}
          <div className="h-[40px] relative rounded-[14px] shrink-0 w-full">
            <div className="flex flex-row items-center size-full">
              <div className="content-stretch flex gap-[12px] items-center pl-[12px] relative size-full">
                <svg className="relative shrink-0 size-[18px]" fill="none" viewBox="0 0 18 18">
                  <g>
                    <path d="M12 12.75L15.75 9L12 5.25" stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                    <path d="M15.75 9H6.75" stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                    <path d={sidebarSvgPaths.p3d8d0000} stroke="#99A1AF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                  </g>
                </svg>
                <div className="h-[20px] relative shrink-0 w-[41.938px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                    <p className="-translate-x-1/2 absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[21px] text-[#4a5565] text-[14px] text-center top-[-1.2px] whitespace-nowrap">Выйти</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="absolute left-[320px] top-0 right-0 h-full">
        {/* Header */}
        <div className="absolute bg-[rgba(255,255,255,0.9)] backdrop-blur-[20px] h-[76px] left-0 top-0 w-full border-b-[0.8px] border-black px-[24px] flex items-center justify-between">
          <div className="flex items-center gap-[16px]">
            <button className="rounded-[14px] size-[41.6px] flex items-center justify-center hover:bg-[rgba(0,0,0,0.05)] transition-colors duration-200">
              <svg className="size-[20px]" fill="none" viewBox="0 0 20 20">
                <path d={svgPaths.p354ab980} stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                <path d={svgPaths.p2a4db200} stroke="#4A5565" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
              </svg>
            </button>

            <div className="flex items-center gap-[12px]">
              <div className="bg-gradient-to-b from-[#f6b044] to-[#f39c12] rounded-[16px] shadow-[0px_25px_50px_0px_rgba(246,176,68,0.2)] size-[44px] flex items-center justify-center relative">
                <div className="size-[28px]">
                  <Mascot />
                </div>
              </div>

              <div>
                <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[24px] text-[#101828] text-[16px] tracking-[-0.4px]">
                  чат с Никой
                </p>
                <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[16px] text-[#6a7282] text-[12px]">
                  твой помощник
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Chat Messages */}
        <div className="absolute top-[76px] left-0 w-full bottom-[146px] bg-[#faf7ec] overflow-y-auto">
          <div className="px-[24px] pt-[32px] pb-[24px] space-y-[4px]">
            {/* NIKA's first message */}
            <div className="flex gap-[12px] items-start">
              <div className="bg-white relative rounded-[16px] size-[40px] border-[0.8px] border-[rgba(0,0,0,0.1)] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1)] flex items-center justify-center overflow-hidden">
                <img alt="NIKA" className="size-[38.4px] object-cover" src={imgImageNika} />
              </div>
              <div className="flex-1 space-y-[8px]">
                <div className="bg-[rgba(255,255,255,0.9)] rounded-[16px] border-[0.8px] border-[rgba(0,0,0,0.1)] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1)] p-[20.8px]">
                  <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[24.375px] text-[#101828] text-[15px]">
                    Привет! Я НИКА, твой помощник по спорту. Я помогу тебе: понять свои спортивные возможности, построить правильный план тренировок, восстанавливаться после нагрузок и многое другое!
                  </p>
                  <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[24.375px] text-[#101828] text-[15px] mt-[12px]">
                    Ответь: Готово\Расскажи подробнее
                  </p>
                </div>
                <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[16px] text-[#99a1af] text-[12px] px-[8px]">
                  17:38
                </p>
              </div>
            </div>

            {/* User response */}
            <div className="flex gap-[12px] items-start justify-end">
              <div className="flex-1 flex flex-col items-end space-y-[8px]">
                <div className="rounded-[16px] border-[0.8px] border-[rgba(246,176,68,0.2)] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1)] px-[20.8px] py-[14.8px]" style={{ backgroundImage: "linear-gradient(148.808deg, rgba(246, 176, 68, 0.15) 0%, rgba(243, 156, 18, 0.1) 100%)" }}>
                  <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[24.375px] text-[#101828] text-[15px]">
                    Готово
                  </p>
                </div>
                <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[16px] text-[#99a1af] text-[12px] px-[8px]">
                  17:39
                </p>
              </div>
              <div className="bg-gradient-to-b from-[#5a6444] to-[#3d2b1f] relative rounded-[16px] size-[40px] border-[0.8px] border-[rgba(0,0,0,0.1)] shadow-[0px_10px_15px_0px_rgba(0,0,0,0.1)] flex items-center justify-center">
                <svg className="size-[20px]" fill="none" viewBox="0 0 20 20">
                  <g>
                    <path d={svgPaths.p2026e800} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
                    <path d={svgPaths.p32ab0300} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.08333" />
                  </g>
                </svg>
              </div>
            </div>

          </div>
        </div>

        {/* Premium Button - Floating above input (Perplexity style) */}
        {!hasSubscription && showPremiumBanner && (
          <div className="absolute bottom-[170px] left-[24px] right-[24px] z-10">
            <div className="relative group w-full rounded-[12px] bg-[rgba(255,255,255,0.95)] backdrop-blur-[20px] border border-[rgba(246,176,68,0.2)] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.08)] transition-all duration-300 hover:bg-white hover:border-[rgba(246,176,68,0.35)] hover:shadow-[0px_4px_12px_0px_rgba(246,176,68,0.15)]">
              <button
                onClick={handleSubscriptionClick}
                className="w-full text-center py-[12px] px-[40px] pr-[16px]"
              >
                <div className="flex items-center justify-center gap-[8px]">
                  <svg className="size-[16px] opacity-60 group-hover:opacity-80 transition-opacity" fill="none" viewBox="0 0 16 16">
                    <path d="M8 0.8L9.9776 6.368L16 7.012L12 10.944L13.1552 16L8 13.088L2.8448 16L4 10.944L0 7.012L6.0224 6.368L8 0.8Z" fill="#f6b044" />
                  </svg>
                  <div className="flex flex-col items-center gap-[2px]">
                    <span className="font-['Arimo:Regular',sans-serif] text-[14px] text-[#4a5565] group-hover:text-[#f6b044] transition-colors">
                      Получить Premium
                    </span>
                    <span className="font-['Arimo:Regular',sans-serif] text-[12px] text-[#99a1af] group-hover:text-[#f6b044] transition-colors">
                      узнать больше
                    </span>
                  </div>
                </div>
              </button>
              <button
                onClick={handleCloseBanner}
                className="absolute top-[12px] right-[12px] size-[20px] rounded-full hover:bg-[rgba(0,0,0,0.05)] flex items-center justify-center transition-colors"
              >
                <svg className="size-[12px]" fill="none" viewBox="0 0 12 12">
                  <path d="M9 3L3 9M3 3L9 9" stroke="#99a1af" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 w-full h-[146px] bg-[rgba(255,255,255,0.8)] backdrop-blur-[20px] border-t-[0.8px] border-black px-[24px] pt-[24px]">
          <div className="bg-white h-[65.6px] relative rounded-[24px] shrink-0 w-full">
            <div aria-hidden="true" className="absolute border-[0.8px] border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[24px] shadow-[0px_10px_15px_0px_rgba(0,0,0,0.1),0px_4px_6px_0px_rgba(0,0,0,0.1)]" />
            <div className="flex flex-row items-end size-full">
              <div className="content-stretch flex gap-[12px] items-end pb-[8.8px] pt-[0.8px] px-[8.8px] relative size-full">
                <div className="h-[44px] relative shrink-0 w-[52px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] relative size-full">
                    <div className="flex-[1_0_0] h-[36px] min-h-px min-w-px relative rounded-[14px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[8px] px-[8px] relative size-full">
                        <div className="h-[20px] overflow-clip relative shrink-0 w-full">
                          <div className="absolute inset-[8.33%_9.76%_8.33%_12.5%]">
                            <div className="absolute inset-[-5%_-5.36%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17.2134 18.333">
                                <path d={svgPaths.p1d7fbb00} stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex-[1_0_0] h-[48px] min-h-px min-w-px relative">
                  <div className="overflow-clip rounded-[inherit] size-full">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start px-[8px] py-[12px] relative size-full">
                      <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[24px] relative shrink-0 text-[#99a1af] text-[16px] whitespace-nowrap">Напишите сообщение или нажмите / для команд...</p>
                    </div>
                  </div>
                </div>
                <div className="h-[46px] relative shrink-0 w-[98px]">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-start px-[8px] relative size-full">
                    <div className="h-[38px] relative rounded-[14px] shrink-0 w-[36px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[9px] px-[8px] relative size-full">
                        <div className="h-[20px] overflow-clip relative shrink-0 w-full">
                          <div className="absolute bottom-[8.33%] left-1/2 right-1/2 top-[79.17%]">
                            <div className="absolute inset-[-33.33%_-0.83px]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.66667 4.16667">
                                <path d="M0.833333 0.833333V3.33333" stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                              </svg>
                            </div>
                          </div>
                          <div className="absolute inset-[41.67%_20.83%_20.83%_20.83%]">
                            <div className="absolute inset-[-11.11%_-7.14%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 9.16667">
                                <path d={svgPaths.p1a8a3b00} stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                              </svg>
                            </div>
                          </div>
                          <div className="absolute inset-[8.33%_37.5%_37.5%_37.5%]">
                            <div className="absolute inset-[-7.69%_-16.67%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.66667 12.5">
                                <path d={svgPaths.p127c7400} stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-[#e5e7eb] flex-[1_0_0] h-[38px] min-h-px min-w-px relative rounded-[14px]">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[10px] px-[10px] relative size-full">
                        <div className="h-[18px] overflow-clip relative shrink-0 w-full">
                          <div className="absolute inset-[8.32%_8.32%_8.33%_8.33%]">
                            <div className="absolute inset-[-6.25%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.8767 16.8767">
                                <path d={svgPaths.p2612f580} stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                              </svg>
                            </div>
                          </div>
                          <div className="absolute inset-[8.95%_8.94%_45.47%_45.47%]">
                            <div className="absolute inset-[-11.43%]">
                              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.08 10.0793">
                                <path d={svgPaths.p16097080} stroke="var(--stroke-0, #99A1AF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.875" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
