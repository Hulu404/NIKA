interface UserProfileProps {
  name: string;
  hasActiveSubscription: boolean;
}

export function UserProfile({ name, hasActiveSubscription }: UserProfileProps) {
  const firstLetter = name.charAt(0).toUpperCase();

  return (
    <div className="relative h-[44px] w-[44px]">
      {/* Subscription Ring */}
      {hasActiveSubscription && (
        <svg
          className="absolute inset-0 size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 47 47"
          style={{ filter: 'drop-shadow(0 0 3px rgba(138, 43, 226, 0.4))' }}
        >
          <circle
            cx="23.5"
            cy="23.5"
            r="20.5"
            stroke="url(#subscription-gradient)"
            strokeWidth="6"
            strokeLinecap="round"
            strokeDasharray="6 3"
          />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="subscription-gradient" x1="23.5" x2="23.5" y1="0" y2="47">
              <stop stopColor="#8B5CF6" />
              <stop offset="0.33" stopColor="#A78BFA" />
              <stop offset="0.66" stopColor="#C084FC" />
              <stop offset="1" stopColor="#E879F9" />
            </linearGradient>
          </defs>
        </svg>
      )}

      {/* Avatar Container */}
      <div className="absolute inset-[3px] flex items-center justify-center">
        <div className="relative size-full">
          {/* Avatar Circle */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#f6b044] to-[#f39c12] rounded-[16px] shadow-[0px_4px_12px_0px_rgba(246,176,68,0.3)] flex items-center justify-center">
            <p className="font-['Arimo:Bold',sans-serif] font-bold leading-[20px] text-[14px] text-white">
              {firstLetter}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
