function Container1() {
  return <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[293px] rounded-[26843500px] size-[384px] top-[-159px]" data-name="Container" />;
}

function Container2() {
  return <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" data-name="Container" />;
}

function Component() {
  return (
    <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[581px] left-[-425.5px] opacity-50 rounded-[26843500px] top-0 w-[894px]" data-name="цвет на фон">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container1 />
        <Container2 />
      </div>
    </div>
  );
}

function MotivationSlider() {
  return (
    <div className="h-[208px] relative shrink-0 w-[624px]" data-name="MotivationSlider">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start not-italic relative size-full text-center">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold h-[120px] leading-[60px] relative shrink-0 text-[#101828] text-[48px] w-full">Психологический онбординг</p>
        <p className="font-['Inter:Regular',sans-serif] font-normal h-[64px] leading-[32px] relative shrink-0 text-[#4a5565] text-[24px] w-full">Шкала дистресса Кесслера (K-6)</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[rgba(243,244,246,0.42)] h-[68px] left-[49px] rounded-[16px] top-[401px] w-[526px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-[263.67px] not-italic text-[#99a1af] text-[18px] text-center top-[20px] whitespace-nowrap">Начать</p>
    </div>
  );
}

function MotivationSlider1() {
  return (
    <div className="bg-white h-[377px] relative rounded-[24px] shrink-0 w-[624px]" data-name="MotivationSlider">
      <div aria-hidden="true" className="absolute border border-[#f3f4f6] border-solid inset-0 pointer-events-none rounded-[24px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.1),0px_1px_2px_0px_rgba(0,0,0,0.1)]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button />
        <div className="absolute font-['Inter:Regular',sans-serif] font-normal h-[300px] leading-[0] left-[48.5px] not-italic text-[#4a5565] text-[24px] top-[41.5px] w-[526px] whitespace-pre-wrap">
          <p className="leading-[32px] mb-0">Вам предстоит ответить всего на 6 вопросов о том, как вы себя чувствовали в течение последних 30 дней.</p>
          <p className="leading-[32px] mb-0">​</p>
          <p className="leading-[32px]">{`Это признанный в мировой психологии инструмент. Результаты не ставят диагноз и не оценивают вас как личность, а просто помогают нам понять ваш текущий эмоциональный фон. `}</p>
        </div>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="flex-[774_0_0] min-h-px relative w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[48px] items-start justify-center relative size-full">
        <MotivationSlider />
        <MotivationSlider1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="flex-[906_0_0] min-h-px relative w-[672px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[48px] items-start px-[24px] py-[32px] relative size-full">
        <Component />
        <Container3 />
      </div>
    </div>
  );
}

function OnboardingWizard() {
  return (
    <div className="bg-[#faf7ec] content-stretch flex flex-col h-[906px] items-start pl-[425.5px] relative shrink-0 w-[1523px]" data-name="OnboardingWizard">
      <Container />
    </div>
  );
}

function Body() {
  return (
    <div className="content-stretch flex flex-col h-[877px] items-start relative shrink-0 w-full" data-name="Body">
      <OnboardingWizard />
    </div>
  );
}

export default function Component1() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="0">
      <Body />
    </div>
  );
}