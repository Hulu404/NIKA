
  # Create Page Navigation Flow

  This is a code bundle for Create Page Navigation Flow. The original project is available at https://www.figma.com/design/2yDx0AmFvwZ0eg9hr12S9L/Create-Page-Navigation-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  