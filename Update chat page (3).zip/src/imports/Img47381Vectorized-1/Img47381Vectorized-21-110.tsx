import svgPaths from "./svg-ckwyhnbf8g";

export default function Img47381Vectorized() {
  return (
    <div className="relative size-full" data-name="IMG_4738 1 [Vectorized]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="IMG_4738 1 [Vectorized]">
          <path d={svgPaths.p19ea000} fill="var(--fill-0, white)" id="Vector" />
          <path d={svgPaths.p30672dc0} fill="var(--fill-0, white)" id="Vector_2" />
          <path d={svgPaths.p19b4c980} fill="var(--fill-0, white)" id="Vector_3" />
          <path d={svgPaths.p27986700} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p28e31bf0} fill="var(--fill-0, white)" id="Vector_5" />
          <path d={svgPaths.p30c17f00} fill="var(--fill-0, white)" id="Vector_6" />
          <path d={svgPaths.p13a39b00} fill="var(--fill-0, white)" id="Vector_7" />
          <path d={svgPaths.pd1e5e0} fill="var(--fill-0, white)" id="Vector_8" />
          <path d={svgPaths.p3bff1080} fill="var(--fill-0, white)" id="Vector_9" />
          <path d={svgPaths.p1d1af270} fill="var(--fill-0, white)" id="Vector_10" />
          <path d={svgPaths.p3ce27700} fill="var(--fill-0, white)" id="Vector_11" />
          <path d={svgPaths.p345f4100} fill="var(--fill-0, white)" id="Vector_12" />
          <path d={svgPaths.p295f0280} fill="var(--fill-0, white)" id="Vector_13" />
          <path d={svgPaths.p2d07a000} fill="var(--fill-0, white)" id="Vector_14" />
          <path d={svgPaths.p35441900} fill="var(--fill-0, white)" id="Vector_15" />
          <path d={svgPaths.p3e34ecf0} fill="var(--fill-0, white)" id="Vector_16" />
          <path d={svgPaths.p107c9b00} fill="var(--fill-0, white)" id="Vector_17" />
          <path d={svgPaths.p1c870bf0} fill="var(--fill-0, white)" id="Vector_18" />
          <path d={svgPaths.p1d387a80} fill="var(--fill-0, white)" id="Vector_19" />
          <path d={svgPaths.p35294f00} fill="var(--fill-0, white)" id="Vector_20" />
          <path d={svgPaths.p2f114600} fill="var(--fill-0, white)" id="Vector_21" />
          <path d={svgPaths.p12aa0800} fill="var(--fill-0, white)" id="Vector_22" />
          <path d={svgPaths.p3cdf63f0} fill="var(--fill-0, white)" id="Vector_23" />
          <path d={svgPaths.pfe8d480} fill="var(--fill-0, white)" id="Vector_24" />
          <path d={svgPaths.p3711b7f0} fill="var(--fill-0, white)" id="Vector_25" />
          <path d={svgPaths.p1c26d532} fill="var(--fill-0, white)" id="Vector_26" />
          <path d={svgPaths.p12021300} fill="var(--fill-0, white)" id="Vector_27" />
          <path d={svgPaths.pbda8a72} fill="var(--fill-0, white)" id="Vector_28" />
          <path d={svgPaths.p16a03310} fill="var(--fill-0, white)" id="Vector_29" />
          <path d={svgPaths.p27180b00} fill="var(--fill-0, white)" id="Vector_30" />
          <path d={svgPaths.p3f9c3680} fill="var(--fill-0, white)" id="Vector_31" />
          <path d={svgPaths.p232ba6f0} fill="var(--fill-0, white)" id="Vector_32" />
          <path d={svgPaths.p29c88d80} fill="var(--fill-0, white)" id="Vector_33" />
          <path d={svgPaths.p10605800} fill="var(--fill-0, white)" id="Vector_34" />
          <path d={svgPaths.p27b2c100} fill="var(--fill-0, white)" id="Vector_35" />
          <path d={svgPaths.p3b791700} fill="var(--fill-0, white)" id="Vector_36" />
          <path d={svgPaths.p33476100} fill="var(--fill-0, white)" id="Vector_37" />
          <path d={svgPaths.p33d05200} fill="var(--fill-0, white)" id="Vector_38" />
          <path d={svgPaths.p3f0e6400} fill="var(--fill-0, white)" id="Vector_39" />
          <path d={svgPaths.p49b9680} fill="var(--fill-0, white)" id="Vector_40" />
          <path d={svgPaths.p1ea39000} fill="var(--fill-0, white)" id="Vector_41" />
          <path d={svgPaths.p3fd32e00} fill="var(--fill-0, white)" id="Vector_42" />
          <path d={svgPaths.p31765300} fill="var(--fill-0, white)" id="Vector_43" />
          <path d={svgPaths.p245e7600} fill="var(--fill-0, white)" id="Vector_44" />
          <path d={svgPaths.p32601900} fill="var(--fill-0, white)" id="Vector_45" />
          <path d={svgPaths.p2b614380} fill="var(--fill-0, white)" id="Vector_46" />
          <path d={svgPaths.p27f41c00} fill="var(--fill-0, white)" id="Vector_47" />
          <path d={svgPaths.p25969680} fill="var(--fill-0, white)" id="Vector_48" />
          <path d={svgPaths.p12d8d500} fill="var(--fill-0, white)" id="Vector_49" />
          <path d={svgPaths.p329a5000} fill="var(--fill-0, white)" id="Vector_50" />
          <path d={svgPaths.p32fe8800} fill="var(--fill-0, white)" id="Vector_51" />
          <path d={svgPaths.p21a1b100} fill="var(--fill-0, white)" id="Vector_52" />
          <path d={svgPaths.p2d1eae00} fill="var(--fill-0, white)" id="Vector_53" />
          <path d={svgPaths.p10c6ed00} fill="var(--fill-0, white)" id="Vector_54" />
          <path d={svgPaths.pbf79500} fill="var(--fill-0, white)" id="Vector_55" />
          <path d={svgPaths.p2906a3c0} fill="var(--fill-0, white)" id="Vector_56" />
          <path d={svgPaths.p319dc200} fill="var(--fill-0, white)" id="Vector_57" />
          <path d={svgPaths.p11c5a000} fill="var(--fill-0, white)" id="Vector_58" />
          <path d={svgPaths.pd7c1f00} fill="var(--fill-0, white)" id="Vector_59" />
          <path d={svgPaths.p29abe140} fill="var(--fill-0, white)" id="Vector_60" />
          <path d={svgPaths.pb60a80} fill="var(--fill-0, white)" id="Vector_61" />
          <path d={svgPaths.p3b976100} fill="var(--fill-0, white)" id="Vector_62" />
          <path d={svgPaths.p14d2b080} fill="var(--fill-0, white)" id="Vector_63" />
          <path d={svgPaths.p1811f880} fill="var(--fill-0, white)" id="Vector_64" />
          <path d={svgPaths.p13778900} fill="var(--fill-0, white)" id="Vector_65" />
          <path d={svgPaths.p3ce11f00} fill="var(--fill-0, white)" id="Vector_66" />
          <path d={svgPaths.p15419380} fill="var(--fill-0, white)" id="Vector_67" />
          <path d={svgPaths.p3dd06a80} fill="var(--fill-0, white)" id="Vector_68" />
          <path d={svgPaths.p1a01cbf2} fill="var(--fill-0, white)" id="Vector_69" />
          <path d={svgPaths.pe90f300} fill="var(--fill-0, white)" id="Vector_70" />
          <path d={svgPaths.p34d08580} fill="var(--fill-0, white)" id="Vector_71" />
          <path d={svgPaths.p12d38900} fill="var(--fill-0, white)" id="Vector_72" />
          <path d={svgPaths.p388f1b00} fill="var(--fill-0, white)" id="Vector_73" />
          <path d={svgPaths.p18232480} fill="var(--fill-0, white)" id="Vector_74" />
          <path d={svgPaths.p19e8c980} fill="var(--fill-0, white)" id="Vector_75" />
          <path d={svgPaths.p21190d00} fill="var(--fill-0, white)" id="Vector_76" />
          <path d={svgPaths.p2a001700} fill="var(--fill-0, white)" id="Vector_77" />
          <path d={svgPaths.p30993980} fill="var(--fill-0, white)" id="Vector_78" />
          <path d={svgPaths.p35bdb500} fill="var(--fill-0, white)" id="Vector_79" />
          <path d={svgPaths.pcd05900} fill="var(--fill-0, white)" id="Vector_80" />
          <path d={svgPaths.p2b028ac0} fill="var(--fill-0, white)" id="Vector_81" />
          <path d={svgPaths.p2ad8180} fill="var(--fill-0, white)" id="Vector_82" />
          <path d={svgPaths.p3144df00} fill="var(--fill-0, white)" id="Vector_83" />
          <path d={svgPaths.p3fb0d480} fill="var(--fill-0, white)" id="Vector_84" />
          <path d={svgPaths.p14fbcc80} fill="var(--fill-0, white)" id="Vector_85" />
          <path d={svgPaths.p21a16c00} fill="var(--fill-0, white)" id="Vector_86" />
          <path d={svgPaths.p14d04680} fill="var(--fill-0, white)" id="Vector_87" />
          <path d={svgPaths.p2e20f500} fill="var(--fill-0, white)" id="Vector_88" />
          <path d={svgPaths.p13d0e840} fill="var(--fill-0, white)" id="Vector_89" />
          <path d={svgPaths.pe1ca180} fill="var(--fill-0, white)" id="Vector_90" />
          <path d={svgPaths.pe008900} fill="var(--fill-0, white)" id="Vector_91" />
          <path d={svgPaths.p3cf56270} fill="var(--fill-0, white)" id="Vector_92" />
          <path d={svgPaths.pd023a00} fill="var(--fill-0, white)" id="Vector_93" />
          <path d={svgPaths.p2dc92e40} fill="var(--fill-0, white)" id="Vector_94" />
          <path d={svgPaths.p23918f00} fill="var(--fill-0, white)" id="Vector_95" />
          <path d={svgPaths.p7c2f400} fill="var(--fill-0, white)" id="Vector_96" />
          <path d={svgPaths.p3b25d400} fill="var(--fill-0, white)" id="Vector_97" />
          <path d={svgPaths.p29dc7e00} fill="var(--fill-0, white)" id="Vector_98" />
          <path d={svgPaths.p3f1e2200} fill="var(--fill-0, white)" id="Vector_99" />
          <path d={svgPaths.p30987c00} fill="var(--fill-0, white)" id="Vector_100" />
          <path d={svgPaths.p27abf000} fill="var(--fill-0, white)" id="Vector_101" />
          <path d={svgPaths.p3e588700} fill="var(--fill-0, white)" id="Vector_102" />
          <path d={svgPaths.p3a276280} fill="var(--fill-0, white)" fillOpacity="0.0156863" id="Vector_103" />
          <path d={svgPaths.p3ed75e00} fill="var(--fill-0, white)" fillOpacity="0.0352941" id="Vector_104" />
        </g>
      </svg>
    </div>
  );
}