import svgPaths from '../../imports/СтраницаОформитьПодписку/svg-z9oi9p46gx';

interface PremiumPageProps {
  onClose: () => void;
}

export function PremiumPage({ onClose }: PremiumPageProps) {
  return (
    <div className="fixed inset-0 bg-[#fffee7] z-50 flex items-center justify-center">
      {/* Back Button */}
      <button
        onClick={onClose}
        className="absolute left-[32px] top-[32px] flex items-center gap-[8px] h-[24px] hover:opacity-70 transition-opacity"
      >
        <svg className="size-[24px]" fill="none" viewBox="0 0 24 24">
          <g>
            <path d="M12 19L5 12L12 5" stroke="#83451E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            <path d="M19 12H5" stroke="#83451E" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </g>
        </svg>
        <div className="h-[24px] relative w-[45.85px]">
          <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-0 text-[#83451e] text-[16px] text-center top-[0.2px] whitespace-nowrap">Назад</p>
        </div>
      </button>

      {/* Premium Card */}
      <div className="bg-white h-[539px] overflow-clip rounded-[30px] shadow-[0px_10px_15px_-3px_rgba(0,0,0,0.1),0px_4px_6px_-4px_rgba(0,0,0,0.1)] w-[448px] relative">
        {/* Top accent bar */}
        <div className="absolute bg-[#f5a623] h-[8px] left-0 top-0 w-full" />

        {/* Header */}
        <div className="absolute flex flex-col gap-[8px] h-[104px] items-start left-[48px] top-[48px] w-[352px]">
          <div className="h-[48px] relative shrink-0 w-full">
            <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[48px] left-1/2 -translate-x-1/2 text-[#3d1f00] text-[32px] text-center top-[1.4px] whitespace-nowrap">Premium</p>
          </div>
          <div className="h-[48px] relative shrink-0 w-full">
            <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-1/2 -translate-x-1/2 text-[#83451e] text-[16px] text-center top-[0.2px] w-[248px]">Получите полный доступ ко всем возможностям NIKA</p>
          </div>
        </div>

        {/* Price */}
        <div className="absolute h-[48px] left-[48px] top-[184px] w-[352px]">
          <p className="absolute font-['Arimo:Bold',sans-serif] font-bold leading-[48px] left-[86.67px] text-[#3d1f00] text-[48px] top-[-0.2px] whitespace-nowrap">299</p>
          <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[36px] left-[174.76px] top-[8.8px] text-[#83451e] text-[24px] whitespace-nowrap">руб.</p>
          <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[24px] left-[228.52px] top-[16.2px] text-[#83451e] text-[16px] whitespace-nowrap">/ мес</p>
        </div>

        {/* Features */}
        <div className="absolute flex flex-col gap-[16px] h-[120px] items-start left-[48px] top-[272px] w-[352px]">
          {/* Feature 1 */}
          <div className="h-[40px] relative shrink-0 w-full">
            <div className="absolute bg-[#f5a623] flex flex-col items-start pt-[4px] px-[4px] rounded-full size-[20px] top-[4px] left-0">
              <div className="h-[12px] overflow-clip relative shrink-0 w-full">
                <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4">
                  <div className="absolute inset-[-13.64%_-9.38%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
                      <path d={svgPaths.p1c198100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[32px] text-[#3d1f00] text-[16px] top-[-0.2px] w-[306px]">Полный доступ к персонализированному сопровождению</p>
          </div>

          {/* Feature 2 */}
          <div className="h-[24px] relative shrink-0 w-full">
            <div className="absolute bg-[#f5a623] flex flex-col items-start pt-[4px] px-[4px] rounded-full size-[20px] top-[4px] left-0">
              <div className="h-[12px] overflow-clip relative shrink-0 w-full">
                <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4">
                  <div className="absolute inset-[-13.64%_-9.38%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
                      <path d={svgPaths.p1c198100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[32px] top-[3.9px] text-[#3d1f00] text-[16px] whitespace-nowrap">Расширенный анализ данных</p>
          </div>

          {/* Feature 3 */}
          <div className="h-[24px] relative shrink-0 w-full">
            <div className="absolute bg-[#f5a623] flex flex-col items-start pt-[4px] px-[4px] rounded-full size-[20px] top-[4px] left-0">
              <div className="h-[12px] overflow-clip relative shrink-0 w-full">
                <div className="absolute bottom-[29.17%] left-[16.67%] right-[16.67%] top-1/4">
                  <div className="absolute inset-[-13.64%_-9.38%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 7">
                      <path d={svgPaths.p1c198100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            <p className="absolute font-['Arimo:Regular',sans-serif] font-normal leading-[20px] left-[32px] top-[3.9px] text-[#3d1f00] text-[16px] whitespace-nowrap">Постоянная адаптация личной стратегии</p>
          </div>
        </div>

        {/* Subscribe Button */}
        <button className="absolute bg-[#f5a623] h-[59px] left-[48px] rounded-[15px] shadow-[0px_4px_6px_0px_rgba(0,0,0,0.1),0px_2px_4px_0px_rgba(0,0,0,0.1)] top-[432px] w-[352px] hover:bg-[#e69519] transition-colors">
          <p className="font-['Arimo:Regular',sans-serif] font-normal leading-[27px] text-[18px] text-center text-white whitespace-nowrap">Оформить подписку</p>
        </button>
      </div>
    </div>
  );
}
