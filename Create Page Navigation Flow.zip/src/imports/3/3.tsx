import svgPaths from "./svg-36dojgs6qm";

function Container3() {
  return <div className="absolute bg-[#7c86ff] h-[6px] left-0 rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container4() {
  return <div className="absolute bg-[#4f39f6] h-[6px] left-[80px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container5() {
  return <div className="absolute bg-[#7c86ff] h-[6px] left-[40px] rounded-[33554400px] top-0 w-[32px]" data-name="Container" />;
}

function Container2() {
  return (
    <div className="absolute h-[6px] left-[256.5px] top-[9px] w-[112px]" data-name="Container">
      <Container3 />
      <Container4 />
      <Container5 />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute h-[20px] left-[601.41px] top-0 w-[22.594px]" data-name="Text">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#6a7282] text-[14px] top-0 whitespace-nowrap">2/3</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="absolute left-[15px] size-[24px] top-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_167)" id="Icon">
          <path d="M9 12L3 6L9 0" id="Vector" stroke="var(--stroke-0, #364153)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
        <defs>
          <clipPath id="clip0_1_167">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-white border border-[#e5e7eb] border-solid left-[0.5px] rounded-[16px] size-[44px] top-[-10px]" data-name="Button">
      <Icon />
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[20px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Container2 />
        <Text />
        <Button />
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[135px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[45px] left-[312px] not-italic text-[#101828] text-[36px] text-center top-[-1px] w-[592px]">Представь, что ты неделю тренировался, а вес или объёмы не изменились.</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[32px] left-[312.14px] not-italic text-[#4a5565] text-[24px] text-center top-[-1px] whitespace-nowrap">Какая мысль первой приходит в голову?</p>
    </div>
  );
}

function LocusCase() {
  return (
    <div className="h-[191px] relative shrink-0 w-[624px]" data-name="LocusCase">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start relative size-full">
        <Heading />
        <Paragraph />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d={svgPaths.p3a098740} id="Vector" stroke="var(--stroke-0, #B139F6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.33333" />
          <path d="M24.5 24.5L19.4833 19.4833" id="Vector_2" stroke="var(--stroke-0, #B139F6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute bg-[#f6e0ff] content-stretch flex items-center justify-center left-[24px] px-[14px] rounded-[16px] size-[56px] top-[27.13px]" data-name="Container">
      <Icon1 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="absolute h-[117px] left-[24px] top-[111.13px] w-[250px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.25px] left-0 not-italic text-[#364153] text-[18px] top-px w-[250px]">Наверное, я что-то делаю не так в питании или технике. Надо разобраться и скорректировать.</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute content-stretch flex h-[24px] items-start justify-end left-[24px] top-[243.63px] w-[250px]" data-name="Container">
      <Container10 />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[310.25px] left-0 rounded-[24px] top-0 w-[302px]" data-name="Button">
      <Container8 />
      <Paragraph1 />
      <Container9 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d={svgPaths.p20644980} id="Vector" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.33333" />
          <path d={svgPaths.p1bea5e80} id="Vector_2" stroke="var(--stroke-0, #009966)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.33333" />
        </g>
      </svg>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute bg-[#d0fae5] content-stretch flex items-center justify-center left-[24px] px-[14px] rounded-[16px] size-[56px] top-[24px]" data-name="Container">
      <Icon2 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute h-[146.25px] left-[24px] top-[96px] w-[250px]" data-name="Paragraph">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[29.25px] left-0 not-italic text-[#364153] text-[18px] top-[16.13px] w-[250px]">Организм просто так устроен — генетика, метаболизм. Иногда прогресса нет, и это нормально.</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="relative rounded-[33554400px] shrink-0 size-[24px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-2 border-[#d1d5dc] border-solid inset-0 pointer-events-none rounded-[33554400px]" />
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute content-stretch flex h-[24px] items-start justify-end left-[24px] top-[258.25px] w-[250px]" data-name="Container">
      <Container13 />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-white border-2 border-[#e5e7eb] border-solid h-[310.25px] left-[322px] rounded-[24px] top-0 w-[302px]" data-name="Button">
      <Container11 />
      <Paragraph2 />
      <Container12 />
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[310.25px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button1 />
        <Button2 />
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="bg-[#f3f4f6] flex-[556_0_0] h-[68px] min-w-px relative rounded-[16px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-[311.5px] not-italic text-[#99a1af] text-[18px] text-center top-[19.88px] whitespace-nowrap">Завершить</p>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[68px] relative shrink-0 w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <Button3 />
      </div>
    </div>
  );
}

function LocusCase1() {
  return (
    <div className="flex-[506_0_0] min-h-px relative w-[624px]" data-name="LocusCase">
      <div className="flex flex-col justify-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[32px] items-start justify-center py-[47.875px] relative size-full">
          <Container7 />
          <Container14 />
        </div>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="flex-[745_0_0] min-h-px relative w-[624px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[48px] items-start relative size-full">
        <LocusCase />
        <LocusCase1 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="flex-[877_0_0] min-h-px relative w-[672px]" data-name="Container">
      <div className="content-stretch flex flex-col gap-[48px] items-start px-[24px] py-[32px] relative size-full">
        <Container1 />
        <Container6 />
      </div>
    </div>
  );
}

function OnboardingWizard() {
  return (
    <div className="bg-[#faf7ec] h-[877px] relative shrink-0 w-full" data-name="OnboardingWizard">
      <div className="content-stretch flex flex-col items-start pl-[435px] relative size-full">
        <Container />
      </div>
    </div>
  );
}

function Container16() {
  return <div className="absolute bg-[rgba(243,156,18,0.08)] blur-[64px] left-[293px] rounded-[26843500px] size-[384px] top-[-159px]" data-name="Container" />;
}

function Container17() {
  return <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] left-[-94px] opacity-50 rounded-[26843500px] size-[384px] top-[-86px]" data-name="Container" />;
}

function Container15() {
  return (
    <div className="absolute bg-[rgba(246,176,68,0.08)] blur-[64px] h-[453px] left-[-42px] opacity-50 rounded-[26843500px] top-[-24px] w-[954px]" data-name="Container">
      <Container16 />
      <Container17 />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="3">
      <OnboardingWizard />
      <Container15 />
    </div>
  );
}